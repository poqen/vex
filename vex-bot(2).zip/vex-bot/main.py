import logging

from vex import config
from vex.bot import VexBot


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    if not config.TOKEN:
        raise SystemExit("Не задана переменная окружения DISCORD_TOKEN")
    bot = VexBot()
    bot.run(config.TOKEN, log_handler=None)


if __name__ == "__main__":
    main()
