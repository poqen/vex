"""Сообщения от имени бота: простой текст и полноценный конструктор эмбедов."""
import json
import re
from dataclasses import dataclass, field

import discord
from discord import app_commands
from discord.ext import commands

from .. import config, embeds
from ..checks import access

URL_RE = re.compile(r"^https?://", re.IGNORECASE)
BUILDER_TIMEOUT = 900  # 15 минут на сборку сообщения


def parse_color(raw):
    """'#8B5CF6', '8b5cf6', 'purple', 'random' -> int. None, если не разобрали."""
    raw = (raw or "").strip().lower()
    if not raw:
        return None
    if raw == "random":
        return discord.Colour.random().value
    if raw in config.NAMED_COLORS:
        return config.NAMED_COLORS[raw]
    cleaned = raw.lstrip("#")
    if cleaned.startswith("0x"):
        cleaned = cleaned[2:]
    try:
        return int(cleaned, 16) & 0xFFFFFF
    except ValueError:
        return None


def valid_url(value, allow_attachment=False):
    """Пускаем только http/https (и attachment:// для вложений)."""
    if not value:
        return True
    if allow_attachment and value.startswith("attachment://"):
        return True
    return bool(URL_RE.match(value))


# --------------------------------------------------------------------------- черновик
@dataclass
class EmbedDraft:
    """Все поля эмбеда Discord в одном месте + текст вне эмбеда."""

    content: str = ""
    title: str = ""
    url: str = ""
    description: str = ""
    color: int = config.COLOR_MAIN
    author_name: str = ""
    author_icon: str = ""
    author_url: str = ""
    footer_text: str = ""
    footer_icon: str = ""
    thumbnail: str = ""
    image: str = ""
    timestamp: bool = False
    fields: list = field(default_factory=list)
    ping_role_id: int = 0

    # ---- вывод
    def has_embed(self):
        return any([self.title, self.description, self.author_name, self.footer_text,
                    self.thumbnail, self.image, self.fields])

    def is_empty(self):
        return not self.has_embed() and not self.content

    def to_embed(self):
        if not self.has_embed():
            return None
        embed = discord.Embed(
            title=self.title[:256] or None,
            url=self.url or None,
            description=self.description[:4000] or None,
            color=self.color,
        )
        if self.timestamp:
            embed.timestamp = discord.utils.utcnow()
        if self.author_name:
            embed.set_author(name=self.author_name[:256],
                             icon_url=self.author_icon or None,
                             url=self.author_url or None)
        if self.footer_text:
            embed.set_footer(text=self.footer_text[:2048], icon_url=self.footer_icon or None)
        if self.thumbnail:
            embed.set_thumbnail(url=self.thumbnail)
        if self.image:
            embed.set_image(url=self.image)
        for item in self.fields[:25]:
            embed.add_field(name=str(item.get("name", "—"))[:256],
                            value=str(item.get("value", "—"))[:1024],
                            inline=bool(item.get("inline")))
        return embed

    def full_content(self):
        """Текст сообщения вместе с пингом роли, если он выбран."""
        parts = []
        if self.ping_role_id:
            parts.append(f"<@&{self.ping_role_id}>")
        if self.content:
            parts.append(self.content)
        return " ".join(parts)[:2000] or None

    # ---- JSON (формат Discord: {"content": ..., "embeds": [ {...} ]})
    def to_json(self):
        data = {}
        if self.content:
            data["content"] = self.content
        body = {}
        if self.title:
            body["title"] = self.title
        if self.url:
            body["url"] = self.url
        if self.description:
            body["description"] = self.description
        body["color"] = self.color
        if self.timestamp:
            body["timestamp"] = discord.utils.utcnow().isoformat()
        if self.author_name:
            author = {"name": self.author_name}
            if self.author_icon:
                author["icon_url"] = self.author_icon
            if self.author_url:
                author["url"] = self.author_url
            body["author"] = author
        if self.footer_text:
            footer = {"text": self.footer_text}
            if self.footer_icon:
                footer["icon_url"] = self.footer_icon
            body["footer"] = footer
        if self.thumbnail:
            body["thumbnail"] = {"url": self.thumbnail}
        if self.image:
            body["image"] = {"url": self.image}
        if self.fields:
            body["fields"] = [
                {"name": f.get("name", "—"), "value": f.get("value", "—"),
                 "inline": bool(f.get("inline"))}
                for f in self.fields
            ]
        if self.has_embed():
            data["embeds"] = [body]
        if self.ping_role_id:
            data["ping_role_id"] = self.ping_role_id
        return data

    def to_json_text(self):
        return json.dumps(self.to_json(), ensure_ascii=False, indent=2)

    @classmethod
    def from_json(cls, data):
        """Понимает и {'content':..,'embeds':[..]}, и просто словарь эмбеда."""
        if not isinstance(data, dict):
            raise ValueError("Ожидается JSON-объект")
        draft = cls()
        draft.content = str(data.get("content") or "")[:2000]
        try:
            draft.ping_role_id = int(data.get("ping_role_id") or 0)
        except (TypeError, ValueError):
            draft.ping_role_id = 0

        body = None
        if isinstance(data.get("embeds"), list) and data["embeds"]:
            body = data["embeds"][0]
        elif isinstance(data.get("embed"), dict):
            body = data["embed"]
        elif any(k in data for k in ("title", "description", "fields", "author", "footer",
                                     "image", "thumbnail")):
            body = data
        if not isinstance(body, dict):
            return draft

        draft.title = str(body.get("title") or "")[:256]
        draft.url = str(body.get("url") or "")
        draft.description = str(body.get("description") or "")[:4000]
        color = body.get("color")
        if isinstance(color, str):
            draft.color = parse_color(color) or config.COLOR_MAIN
        elif isinstance(color, int):
            draft.color = color & 0xFFFFFF
        draft.timestamp = bool(body.get("timestamp"))

        author = body.get("author") or {}
        if isinstance(author, dict):
            draft.author_name = str(author.get("name") or "")[:256]
            draft.author_icon = str(author.get("icon_url") or author.get("iconURL") or "")
            draft.author_url = str(author.get("url") or "")
        footer = body.get("footer") or {}
        if isinstance(footer, dict):
            draft.footer_text = str(footer.get("text") or "")[:2048]
            draft.footer_icon = str(footer.get("icon_url") or footer.get("iconURL") or "")
        thumb = body.get("thumbnail") or {}
        if isinstance(thumb, dict):
            draft.thumbnail = str(thumb.get("url") or "")
        elif isinstance(thumb, str):
            draft.thumbnail = thumb
        image = body.get("image") or {}
        if isinstance(image, dict):
            draft.image = str(image.get("url") or "")
        elif isinstance(image, str):
            draft.image = image

        for item in (body.get("fields") or [])[:25]:
            if isinstance(item, dict) and item.get("name") and item.get("value"):
                draft.fields.append({
                    "name": str(item["name"])[:256],
                    "value": str(item["value"])[:1024],
                    "inline": bool(item.get("inline")),
                })
        return draft

    @classmethod
    def from_message(cls, message):
        draft = cls()
        draft.content = (message.content or "")[:2000]
        if message.embeds:
            source = message.embeds[0].to_dict()
            loaded = cls.from_json({"embeds": [source]})
            loaded.content = draft.content
            return loaded
        return draft


# --------------------------------------------------------------------------- модалки
class MainModal(discord.ui.Modal, title="Основное"):
    def __init__(self, view):
        super().__init__()
        self.view_ref = view
        draft = view.draft
        self.f_title = discord.ui.TextInput(label="Заголовок", required=False, max_length=256,
                                            default=draft.title or None)
        self.f_url = discord.ui.TextInput(label="Ссылка заголовка", required=False,
                                          placeholder="https://…", default=draft.url or None)
        self.f_desc = discord.ui.TextInput(label="Описание", style=discord.TextStyle.paragraph,
                                           required=False, max_length=4000,
                                           default=draft.description or None)
        self.f_color = discord.ui.TextInput(
            label="Цвет", required=False, max_length=20,
            placeholder="#8B5CF6, purple, green, red, orange, blue, blurple, random",
            default=f"#{draft.color:06X}",
        )
        for item in (self.f_title, self.f_url, self.f_desc, self.f_color):
            self.add_item(item)

    async def on_submit(self, interaction):
        draft = self.view_ref.draft
        url = str(self.f_url).strip()
        if not valid_url(url):
            await self.view_ref.fail(interaction, "Ссылка заголовка должна начинаться с http:// или https://")
            return
        color = parse_color(str(self.f_color))
        if str(self.f_color).strip() and color is None:
            await self.view_ref.fail(interaction, "Не понял цвет. Примеры: `#8B5CF6`, `purple`, `random`.")
            return
        draft.title = str(self.f_title).strip()
        draft.url = url
        draft.description = str(self.f_desc)
        if color is not None:
            draft.color = color
        await self.view_ref.refresh(interaction)


class AuthorModal(discord.ui.Modal, title="Автор эмбеда"):
    def __init__(self, view):
        super().__init__()
        self.view_ref = view
        draft = view.draft
        self.f_name = discord.ui.TextInput(label="Имя", required=False, max_length=256,
                                           default=draft.author_name or None)
        self.f_icon = discord.ui.TextInput(label="Иконка (URL)", required=False,
                                           placeholder="https://…", default=draft.author_icon or None)
        self.f_url = discord.ui.TextInput(label="Ссылка", required=False,
                                          placeholder="https://…", default=draft.author_url or None)
        for item in (self.f_name, self.f_icon, self.f_url):
            self.add_item(item)

    async def on_submit(self, interaction):
        icon, url = str(self.f_icon).strip(), str(self.f_url).strip()
        if not valid_url(icon) or not valid_url(url):
            await self.view_ref.fail(interaction, "Ссылки должны начинаться с http:// или https://")
            return
        draft = self.view_ref.draft
        draft.author_name = str(self.f_name).strip()
        draft.author_icon = icon
        draft.author_url = url
        await self.view_ref.refresh(interaction)


class FooterModal(discord.ui.Modal, title="Футер эмбеда"):
    def __init__(self, view):
        super().__init__()
        self.view_ref = view
        draft = view.draft
        self.f_text = discord.ui.TextInput(label="Текст", required=False, max_length=2048,
                                           default=draft.footer_text or None)
        self.f_icon = discord.ui.TextInput(label="Иконка (URL)", required=False,
                                           placeholder="https://…", default=draft.footer_icon or None)
        self.f_time = discord.ui.TextInput(
            label="Показывать время? (да/нет)", required=False, max_length=5,
            default="да" if draft.timestamp else "нет",
        )
        for item in (self.f_text, self.f_icon, self.f_time):
            self.add_item(item)

    async def on_submit(self, interaction):
        icon = str(self.f_icon).strip()
        if not valid_url(icon):
            await self.view_ref.fail(interaction, "Иконка футера должна быть http/https ссылкой.")
            return
        draft = self.view_ref.draft
        draft.footer_text = str(self.f_text).strip()
        draft.footer_icon = icon
        draft.timestamp = str(self.f_time).strip().lower() in ("да", "yes", "true", "1", "+")
        await self.view_ref.refresh(interaction)


class ImagesModal(discord.ui.Modal, title="Картинки"):
    def __init__(self, view):
        super().__init__()
        self.view_ref = view
        draft = view.draft
        self.f_thumb = discord.ui.TextInput(label="Миниатюра (thumbnail)", required=False,
                                            placeholder="https://…", default=draft.thumbnail or None)
        self.f_image = discord.ui.TextInput(label="Большая картинка (image)", required=False,
                                            placeholder="https://…", default=draft.image or None)
        for item in (self.f_thumb, self.f_image):
            self.add_item(item)

    async def on_submit(self, interaction):
        thumb, image = str(self.f_thumb).strip(), str(self.f_image).strip()
        if not valid_url(thumb, True) or not valid_url(image, True):
            await self.view_ref.fail(interaction, "Ссылки на картинки должны быть http/https.")
            return
        draft = self.view_ref.draft
        draft.thumbnail = thumb
        draft.image = image
        await self.view_ref.refresh(interaction)


class ContentModal(discord.ui.Modal, title="Текст вне эмбеда"):
    def __init__(self, view):
        super().__init__()
        self.view_ref = view
        self.f_content = discord.ui.TextInput(
            label="Текст (до 2000 символов)", style=discord.TextStyle.paragraph,
            required=False, max_length=2000, default=view.draft.content or None,
        )
        self.add_item(self.f_content)

    async def on_submit(self, interaction):
        self.view_ref.draft.content = str(self.f_content)
        await self.view_ref.refresh(interaction)


class FieldModal(discord.ui.Modal):
    def __init__(self, view, index=None):
        super().__init__(title="Поле эмбеда" if index is None else "Изменить поле")
        self.view_ref = view
        self.index = index
        current = view.draft.fields[index] if index is not None else {}
        self.f_name = discord.ui.TextInput(label="Название", max_length=256,
                                           default=current.get("name") or None)
        self.f_value = discord.ui.TextInput(label="Текст", style=discord.TextStyle.paragraph,
                                            max_length=1024, default=current.get("value") or None)
        self.f_inline = discord.ui.TextInput(
            label="В строку с другими? (да/нет)", required=False, max_length=5,
            default="да" if current.get("inline") else "нет",
        )
        for item in (self.f_name, self.f_value, self.f_inline):
            self.add_item(item)

    async def on_submit(self, interaction):
        draft = self.view_ref.draft
        item = {
            "name": str(self.f_name).strip()[:256],
            "value": str(self.f_value)[:1024],
            "inline": str(self.f_inline).strip().lower() in ("да", "yes", "true", "1", "+"),
        }
        if self.index is None:
            if len(draft.fields) >= 25:
                await self.view_ref.fail(interaction, "В эмбеде может быть максимум 25 полей.")
                return
            draft.fields.append(item)
        else:
            draft.fields[self.index] = item
        await self.view_ref.refresh(interaction)


class JsonModal(discord.ui.Modal, title="JSON эмбеда"):
    def __init__(self, view):
        super().__init__()
        self.view_ref = view
        self.f_json = discord.ui.TextInput(
            label="Вставь JSON (заменит текущий черновик)",
            style=discord.TextStyle.paragraph,
            max_length=4000,
            placeholder='{"content": "", "embeds": [{"title": "Привет", "description": "Текст"}]}',
        )
        self.add_item(self.f_json)

    async def on_submit(self, interaction):
        try:
            data = json.loads(str(self.f_json))
            draft = EmbedDraft.from_json(data)
        except (ValueError, TypeError) as exc:
            await self.view_ref.fail(interaction, f"Не разобрал JSON: `{exc}`")
            return
        self.view_ref.draft = draft
        await self.view_ref.refresh(interaction)


class TemplateNameModal(discord.ui.Modal, title="Сохранить как шаблон"):
    def __init__(self, view):
        super().__init__()
        self.view_ref = view
        self.f_name = discord.ui.TextInput(label="Название шаблона", max_length=64,
                                           placeholder="например: анонс-вайпа")
        self.add_item(self.f_name)

    async def on_submit(self, interaction):
        name = str(self.f_name).strip().lower()[:64]
        if not name:
            await self.view_ref.fail(interaction, "Название шаблона не может быть пустым.")
            return
        await self.view_ref.cog.bot.db.save_template(
            interaction.guild.id, name, self.view_ref.draft.to_json(), interaction.user.id
        )
        await self.view_ref.refresh(interaction, note=f"💾 Шаблон **{name}** сохранён.")


class TemplateJsonModal(discord.ui.Modal, title="Шаблон из JSON"):
    def __init__(self, cog, name):
        super().__init__()
        self.cog = cog
        self.name = name
        self.f_json = discord.ui.TextInput(
            label="JSON шаблона", style=discord.TextStyle.paragraph, max_length=4000,
            placeholder='{"content": "", "embeds": [{"title": "Заголовок"}]}',
        )
        self.add_item(self.f_json)

    async def on_submit(self, interaction):
        try:
            draft = EmbedDraft.from_json(json.loads(str(self.f_json)))
        except (ValueError, TypeError) as exc:
            await interaction.response.send_message(
                embed=embeds.err(f"Не разобрал JSON: `{exc}`"), ephemeral=True
            )
            return
        await self.cog.bot.db.save_template(
            interaction.guild.id, self.name, draft.to_json(), interaction.user.id
        )
        await interaction.response.send_message(
            embed=embeds.ok(f"Шаблон **{self.name}** сохранён."), ephemeral=True
        )


# --------------------------------------------------------------------------- подменю
class FieldsView(discord.ui.View):
    """Подменю полей: живёт в том же ephemeral-сообщении, что и конструктор."""

    def __init__(self, parent):
        super().__init__(timeout=BUILDER_TIMEOUT)
        self.parent = parent
        self.draft = parent.draft
        self.cog = parent.cog
        self.selected = None
        options = [
            discord.SelectOption(label=f"{i + 1}. {f['name'][:60]}", value=str(i))
            for i, f in enumerate(self.draft.fields[:25])
        ]
        if options:
            select = discord.ui.Select(placeholder="Выбери поле…", options=options, row=0)
            select.callback = self._on_select
            self.add_item(select)

    async def interaction_check(self, interaction):
        return await self.parent.interaction_check(interaction)

    async def _on_select(self, interaction):
        self.selected = int(interaction.data["values"][0])
        await self.refresh(interaction)

    def summary(self):
        if not self.draft.fields:
            text = "Полей пока нет."
        else:
            lines = []
            for i, f in enumerate(self.draft.fields):
                mark = "▶️" if i == self.selected else "  "
                flag = " (в строку)" if f.get("inline") else ""
                lines.append(f"{mark} **{i + 1}. {f['name']}**{flag}\n└ {f['value'][:80]}")
            text = "\n".join(lines)[:3800]
        return embeds.info(text, "📋 Поля эмбеда")

    async def refresh(self, interaction, note=None):
        view = FieldsView(self.parent)
        view.selected = self.selected
        embed = view.summary()
        if note:
            embed.add_field(name="​", value=note, inline=False)
        await interaction.response.edit_message(embeds=[embed], view=view)

    async def fail(self, interaction, text):
        await interaction.response.send_message(embed=embeds.err(text), ephemeral=True)

    @discord.ui.button(label="Добавить", emoji="➕", style=discord.ButtonStyle.success, row=1)
    async def add_field(self, interaction, button):
        await interaction.response.send_modal(FieldModal(self))

    @discord.ui.button(label="Изменить", emoji="✏️", style=discord.ButtonStyle.primary, row=1)
    async def edit_field(self, interaction, button):
        if self.selected is None or self.selected >= len(self.draft.fields):
            await self.fail(interaction, "Сначала выбери поле в меню.")
            return
        await interaction.response.send_modal(FieldModal(self, self.selected))

    @discord.ui.button(label="Удалить", emoji="🗑️", style=discord.ButtonStyle.danger, row=1)
    async def delete_field(self, interaction, button):
        if self.selected is None or self.selected >= len(self.draft.fields):
            await self.fail(interaction, "Сначала выбери поле в меню.")
            return
        removed = self.draft.fields.pop(self.selected)
        self.selected = None
        await self.refresh(interaction, note=f"🗑️ Поле «{removed['name']}» удалено.")

    @discord.ui.button(label="Назад", emoji="⬅️", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, interaction, button):
        await self.parent.refresh(interaction)


class ContentView(discord.ui.View):
    """Подменю «текст вне эмбеда»: сам текст и роль для пинга."""

    def __init__(self, parent):
        super().__init__(timeout=BUILDER_TIMEOUT)
        self.parent = parent
        self.draft = parent.draft
        self.cog = parent.cog
        select = discord.ui.RoleSelect(placeholder="Роль для пинга (необязательно)…", row=0,
                                       min_values=0, max_values=1)
        select.callback = self._on_role
        self.add_item(select)

    async def interaction_check(self, interaction):
        return await self.parent.interaction_check(interaction)

    async def _on_role(self, interaction):
        values = interaction.data.get("values") or []
        self.draft.ping_role_id = int(values[0]) if values else 0
        await self.refresh(interaction)

    def summary(self):
        ping = f"<@&{self.draft.ping_role_id}>" if self.draft.ping_role_id else "—"
        text = (f"**Текст:**\n{self.draft.content or '—'}\n\n**Пинг роли:** {ping}")
        return embeds.info(text[:3800], "💬 Текст вне эмбеда")

    async def refresh(self, interaction, note=None):
        view = ContentView(self.parent)
        embed = view.summary()
        if note:
            embed.add_field(name="​", value=note, inline=False)
        await interaction.response.edit_message(embeds=[embed], view=view)

    async def fail(self, interaction, text):
        await interaction.response.send_message(embed=embeds.err(text), ephemeral=True)

    @discord.ui.button(label="Изменить текст", emoji="✏️", style=discord.ButtonStyle.primary, row=1)
    async def edit_text(self, interaction, button):
        await interaction.response.send_modal(ContentModal(self))

    @discord.ui.button(label="Очистить", emoji="🧹", style=discord.ButtonStyle.secondary, row=1)
    async def clear_text(self, interaction, button):
        self.draft.content = ""
        self.draft.ping_role_id = 0
        await self.refresh(interaction, note="🧹 Текст и пинг очищены.")

    @discord.ui.button(label="Назад", emoji="⬅️", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, interaction, button):
        await self.parent.refresh(interaction)


# --------------------------------------------------------------------------- конструктор
class BuilderView(discord.ui.View):
    def __init__(self, cog, author_id, draft, channel, attachment=None, edit_target=None):
        super().__init__(timeout=BUILDER_TIMEOUT)
        self.cog = cog
        self.author_id = author_id
        self.draft = draft
        self.channel = channel
        self.attachment = attachment
        self.edit_target = edit_target  # сообщение бота, которое правим

        picker = discord.ui.ChannelSelect(
            placeholder="Куда отправить…", row=2, min_values=0, max_values=1,
            channel_types=[discord.ChannelType.text, discord.ChannelType.news],
        )
        picker.callback = self._on_channel
        self.add_item(picker)
        if edit_target is not None:
            picker.disabled = True
            self.send.label = "Сохранить изменения"

    async def interaction_check(self, interaction):
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                embed=embeds.err("Это чужой конструктор — вызови `/say embed` сам."), ephemeral=True
            )
            return False
        return True

    async def _on_channel(self, interaction):
        values = interaction.data.get("values") or []
        if values:
            picked = interaction.guild.get_channel(int(values[0]))
            if picked is not None:
                self.channel = picked
        await self.refresh(interaction)

    # ---- отрисовка
    def status_embed(self, note=None):
        draft = self.draft
        where = self.channel.mention if self.channel else "— не выбран —"
        if self.edit_target is not None:
            where = f"правим [сообщение]({self.edit_target.jump_url})"
        ping = f" · пинг <@&{draft.ping_role_id}>" if draft.ping_role_id else ""
        lines = [
            f"**Куда:** {where}{ping}",
            f"**Цвет:** `#{draft.color:06X}` · **Полей:** {len(draft.fields)} · "
            f"**Время:** {'да' if draft.timestamp else 'нет'}",
        ]
        if draft.content:
            lines.append(f"**Текст вне эмбеда:** {draft.content[:120]}")
        if self.attachment is not None:
            lines.append(f"**Вложение:** `{self.attachment.filename}`")
        if note:
            lines.append(f"\n{note}")
        embed = embeds.make("🛠️ Конструктор сообщения", "\n".join(lines))
        embed.set_footer(text=f"{config.FOOTER} • предпросмотр ниже")
        return embed

    def preview(self, note=None):
        result = [self.status_embed(note)]
        body = self.draft.to_embed()
        if body is not None:
            result.append(body)
        return result

    async def refresh(self, interaction, note=None):
        await interaction.response.edit_message(embeds=self.preview(note), view=self)

    async def fail(self, interaction, text):
        await interaction.response.send_message(embed=embeds.err(text), ephemeral=True)

    # ---- кнопки: ряд 0
    @discord.ui.button(label="Основное", emoji="📝", style=discord.ButtonStyle.primary, row=0)
    async def main_btn(self, interaction, button):
        await interaction.response.send_modal(MainModal(self))

    @discord.ui.button(label="Автор", emoji="👤", style=discord.ButtonStyle.secondary, row=0)
    async def author_btn(self, interaction, button):
        await interaction.response.send_modal(AuthorModal(self))

    @discord.ui.button(label="Футер", emoji="🔻", style=discord.ButtonStyle.secondary, row=0)
    async def footer_btn(self, interaction, button):
        await interaction.response.send_modal(FooterModal(self))

    @discord.ui.button(label="Картинки", emoji="🖼️", style=discord.ButtonStyle.secondary, row=0)
    async def images_btn(self, interaction, button):
        await interaction.response.send_modal(ImagesModal(self))

    @discord.ui.button(label="Поля", emoji="📋", style=discord.ButtonStyle.secondary, row=0)
    async def fields_btn(self, interaction, button):
        view = FieldsView(self)
        await interaction.response.edit_message(embeds=[view.summary()], view=view)

    # ---- кнопки: ряд 1
    @discord.ui.button(label="Текст вне эмбеда", emoji="💬", style=discord.ButtonStyle.secondary, row=1)
    async def content_btn(self, interaction, button):
        view = ContentView(self)
        await interaction.response.edit_message(embeds=[view.summary()], view=view)

    @discord.ui.button(label="Вставить JSON", emoji="🧩", style=discord.ButtonStyle.secondary, row=1)
    async def json_btn(self, interaction, button):
        await interaction.response.send_modal(JsonModal(self))

    @discord.ui.button(label="Показать JSON", emoji="👁️", style=discord.ButtonStyle.secondary, row=1)
    async def show_json_btn(self, interaction, button):
        text = self.draft.to_json_text()
        if len(text) > 1900:
            text = text[:1900] + "\n…"
        await interaction.response.send_message(
            embed=embeds.info(f"```json\n{text}\n```", "🧩 Текущий JSON"), ephemeral=True
        )

    # ---- кнопки: ряд 3
    @discord.ui.button(label="Отправить", emoji="✅", style=discord.ButtonStyle.success, row=3)
    async def send(self, interaction, button):
        await self.cog.deliver(interaction, self)

    @discord.ui.button(label="Сохранить как шаблон", emoji="💾", style=discord.ButtonStyle.primary, row=3)
    async def save_btn(self, interaction, button):
        if self.draft.is_empty():
            await self.fail(interaction, "Нечего сохранять — черновик пуст.")
            return
        await interaction.response.send_modal(TemplateNameModal(self))

    @discord.ui.button(label="Сбросить", emoji="♻️", style=discord.ButtonStyle.secondary, row=3)
    async def reset_btn(self, interaction, button):
        self.draft = EmbedDraft()
        await self.refresh(interaction, note="♻️ Черновик очищен.")

    @discord.ui.button(label="Отмена", emoji="✖️", style=discord.ButtonStyle.danger, row=3)
    async def cancel_btn(self, interaction, button):
        await interaction.response.edit_message(
            embeds=[embeds.info("Конструктор закрыт, ничего не отправлено.")], view=None
        )
        self.stop()


# --------------------------------------------------------------------------- простое /say plain
class SayModal(discord.ui.Modal, title="Сообщение от имени VEX"):
    def __init__(self, cog, channel, reply_to, attachment):
        super().__init__()
        self.cog = cog
        self.channel = channel
        self.reply_to = reply_to
        self.attachment = attachment
        self.body = discord.ui.TextInput(
            label="Текст сообщения", style=discord.TextStyle.paragraph,
            required=True, max_length=2000,
        )
        self.add_item(self.body)

    async def on_submit(self, interaction):
        await interaction.response.defer(ephemeral=True)
        text = str(self.body)

        file = None
        if self.attachment is not None:
            try:
                file = await self.attachment.to_file()
            except discord.HTTPException:
                file = None

        reference = None
        if self.reply_to:
            try:
                reference = await self.channel.fetch_message(self.reply_to)
            except (discord.NotFound, discord.Forbidden):
                reference = None

        mentions = discord.AllowedMentions(users=True, roles=True, everyone=False,
                                           replied_user=False)
        try:
            sent = await self.channel.send(content=text, file=file, reference=reference,
                                           allowed_mentions=mentions)
        except discord.Forbidden:
            await interaction.followup.send(
                embed=embeds.err(f"У меня нет прав писать в {self.channel.mention}."), ephemeral=True
            )
            return

        await self.cog.log_message(interaction, self.channel, sent, text, action="отправлено")
        await interaction.followup.send(
            embed=embeds.ok(f"Отправлено в {self.channel.mention}."), ephemeral=True
        )


# --------------------------------------------------------------------------- модуль
class Staff(commands.Cog):
    say = app_commands.Group(name="say", description="Сообщения от имени бота", guild_only=True)
    template = app_commands.Group(name="template", description="Шаблоны эмбедов", parent=say)

    def __init__(self, bot):
        self.bot = bot

    # ---- общее
    def check_channel(self, interaction, channel):
        """Проверяет, что в канал вообще можно писать. Возвращает канал или None."""
        channel = channel or interaction.channel
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            return None
        if not channel.permissions_for(interaction.guild.me).send_messages:
            return None
        return channel

    async def log_message(self, interaction, channel, message, text, action="отправлено"):
        """Для участников сообщение анонимно, но модерация видит, кто его отправил."""
        entry = embeds.make("🕵️ Сообщение от имени бота", color=config.COLOR_MAIN)
        entry.add_field(name="Действие", value=action, inline=True)
        entry.add_field(name="Отправил",
                        value=f"{interaction.user.mention} (`{interaction.user.id}`)", inline=True)
        entry.add_field(name="Канал", value=channel.mention, inline=True)
        if message is not None:
            entry.add_field(name="Сообщение", value=f"[Перейти]({message.jump_url})", inline=True)
        entry.add_field(name="Текст", value=(text or "—")[:1000], inline=False)
        await self.bot.send_log(interaction.guild, entry)

    async def deliver(self, interaction, view):
        """Отправка или сохранение из конструктора."""
        draft = view.draft
        if draft.is_empty():
            await view.fail(interaction, "Сообщение пустое — заполни хотя бы текст или описание.")
            return
        channel = view.channel
        if channel is None:
            await view.fail(interaction, "Выбери канал в меню ниже.")
            return
        if not channel.permissions_for(interaction.guild.me).send_messages:
            await view.fail(interaction, f"У меня нет прав писать в {channel.mention}.")
            return

        await interaction.response.defer(ephemeral=True)
        embed = draft.to_embed()
        content = draft.full_content()
        mentions = discord.AllowedMentions(users=True, roles=True, everyone=False)

        file = None
        if view.attachment is not None:
            try:
                file = await view.attachment.to_file()
            except discord.HTTPException:
                file = None

        try:
            if view.edit_target is not None:
                await view.edit_target.edit(content=content, embed=embed,
                                            allowed_mentions=mentions)
                sent = view.edit_target
                action = "отредактировано"
            else:
                kwargs = {"content": content, "embed": embed, "allowed_mentions": mentions}
                if file is not None:
                    kwargs["file"] = file
                sent = await channel.send(**kwargs)
                action = "отправлено"
        except discord.Forbidden:
            await interaction.followup.send(
                embed=embeds.err(f"У меня нет прав писать в {channel.mention}."), ephemeral=True
            )
            return
        except discord.HTTPException as exc:
            await interaction.followup.send(
                embed=embeds.err(f"Discord отклонил сообщение: `{exc.text or exc}`"), ephemeral=True
            )
            return

        summary = draft.content or draft.title or draft.description or "—"
        await self.log_message(interaction, channel, sent, summary, action=action)
        await interaction.edit_original_response(
            embeds=[embeds.ok(f"{action.capitalize()}: [перейти]({sent.jump_url})", "Готово")],
            view=None,
        )
        view.stop()

    async def open_builder(self, interaction, draft, channel, attachment=None, edit_target=None):
        view = BuilderView(self, interaction.user.id, draft, channel, attachment, edit_target)
        await interaction.response.send_message(embeds=view.preview(), view=view, ephemeral=True)

    async def template_names(self, interaction, current):
        rows = await self.bot.db.list_templates(interaction.guild.id)
        current = (current or "").lower()
        return [
            app_commands.Choice(name=r["name"], value=r["name"])
            for r in rows if current in r["name"].lower()
        ][:25]

    # ---- команды
    @say.command(name="embed", description="Открыть конструктор сообщения с эмбедом")
    @app_commands.describe(channel="Куда отправить (по умолчанию — текущий канал)",
                           template="Начать с сохранённого шаблона",
                           attachment="Прикрепить файл или картинку")
    @app_commands.autocomplete(template=template_names)
    @access("say")
    async def say_embed(self, interaction: discord.Interaction,
                        channel: discord.TextChannel | None = None,
                        template: str | None = None,
                        attachment: discord.Attachment | None = None):
        target = self.check_channel(interaction, channel)
        if target is None:
            await interaction.response.send_message(
                embed=embeds.err("Выбранный канал недоступен для записи."), ephemeral=True
            )
            return
        draft = EmbedDraft()
        if template:
            payload = await self.bot.db.load_template(interaction.guild.id, template.lower())
            if payload is None:
                await interaction.response.send_message(
                    embed=embeds.err(f"Шаблон **{template}** не найден."), ephemeral=True
                )
                return
            draft = EmbedDraft.from_json(payload)
        if attachment is not None and (attachment.content_type or "").startswith("image/"):
            draft.image = f"attachment://{attachment.filename}"
        await self.open_builder(interaction, draft, target, attachment)

    @say.command(name="plain", description="Быстрое текстовое сообщение без эмбеда")
    @app_commands.describe(channel="Куда отправить (по умолчанию — текущий канал)",
                           reply_to="ID сообщения, на которое ответить",
                           attachment="Прикрепить файл или картинку")
    @access("say")
    async def say_plain(self, interaction: discord.Interaction,
                        channel: discord.TextChannel | None = None,
                        reply_to: str | None = None,
                        attachment: discord.Attachment | None = None):
        target = self.check_channel(interaction, channel)
        if target is None:
            await interaction.response.send_message(
                embed=embeds.err("Выбранный канал недоступен для записи."), ephemeral=True
            )
            return
        reply_id = None
        if reply_to:
            if not reply_to.strip().isdigit():
                await interaction.response.send_message(
                    embed=embeds.err("`reply_to` — это числовой ID сообщения."), ephemeral=True
                )
                return
            reply_id = int(reply_to.strip())
        await interaction.response.send_modal(SayModal(self, target, reply_id, attachment))

    @say.command(name="raw", description="Отправить сообщение сразу из готового JSON")
    @app_commands.describe(data="JSON вида {\"content\": \"…\", \"embeds\": [{…}]}",
                           channel="Куда отправить")
    @access("say")
    async def say_raw(self, interaction: discord.Interaction, data: str,
                      channel: discord.TextChannel | None = None):
        target = self.check_channel(interaction, channel)
        if target is None:
            await interaction.response.send_message(
                embed=embeds.err("Выбранный канал недоступен для записи."), ephemeral=True
            )
            return
        try:
            draft = EmbedDraft.from_json(json.loads(data))
        except (ValueError, TypeError) as exc:
            await interaction.response.send_message(
                embed=embeds.err(f"Не разобрал JSON: `{exc}`"), ephemeral=True
            )
            return
        if draft.is_empty():
            await interaction.response.send_message(
                embed=embeds.err("В этом JSON нечего отправлять."), ephemeral=True
            )
            return
        await interaction.response.defer(ephemeral=True)
        try:
            sent = await target.send(
                content=draft.full_content(), embed=draft.to_embed(),
                allowed_mentions=discord.AllowedMentions(users=True, roles=True, everyone=False),
            )
        except discord.HTTPException as exc:
            await interaction.followup.send(
                embed=embeds.err(f"Discord отклонил сообщение: `{exc.text or exc}`"), ephemeral=True
            )
            return
        await self.log_message(interaction, target, sent,
                               draft.content or draft.title or draft.description)
        await interaction.followup.send(
            embed=embeds.ok(f"Отправлено: [перейти]({sent.jump_url})"), ephemeral=True
        )

    @say.command(name="edit", description="Изменить сообщение, отправленное ботом")
    @app_commands.describe(message_id="ID сообщения бота", channel="Канал с этим сообщением")
    @access("say")
    async def say_edit(self, interaction: discord.Interaction, message_id: str,
                       channel: discord.TextChannel | None = None):
        target = channel or interaction.channel
        if not message_id.strip().isdigit():
            await interaction.response.send_message(
                embed=embeds.err("`message_id` — это числовой ID сообщения."), ephemeral=True
            )
            return
        try:
            message = await target.fetch_message(int(message_id.strip()))
        except (discord.NotFound, discord.Forbidden):
            await interaction.response.send_message(
                embed=embeds.err("Не нашёл сообщение в этом канале."), ephemeral=True
            )
            return
        if message.author.id != self.bot.user.id:
            await interaction.response.send_message(
                embed=embeds.err("Редактировать можно только сообщения, отправленные ботом."),
                ephemeral=True,
            )
            return
        await self.open_builder(interaction, EmbedDraft.from_message(message), target,
                                edit_target=message)

    # ---- шаблоны
    @template.command(name="save", description="Сохранить шаблон эмбеда из JSON")
    @app_commands.describe(name="Название шаблона")
    @access("say")
    async def template_save(self, interaction: discord.Interaction,
                            name: app_commands.Range[str, 1, 64]):
        await interaction.response.send_modal(TemplateJsonModal(self, name.strip().lower()))

    @template.command(name="load", description="Открыть конструктор с сохранённым шаблоном")
    @app_commands.describe(name="Название шаблона", channel="Куда отправлять")
    @app_commands.autocomplete(name=template_names)
    @access("say")
    async def template_load(self, interaction: discord.Interaction, name: str,
                            channel: discord.TextChannel | None = None):
        payload = await self.bot.db.load_template(interaction.guild.id, name.lower())
        if payload is None:
            await interaction.response.send_message(
                embed=embeds.err(f"Шаблон **{name}** не найден."), ephemeral=True
            )
            return
        target = self.check_channel(interaction, channel)
        if target is None:
            await interaction.response.send_message(
                embed=embeds.err("Выбранный канал недоступен для записи."), ephemeral=True
            )
            return
        await self.open_builder(interaction, EmbedDraft.from_json(payload), target)

    @template.command(name="list", description="Список сохранённых шаблонов")
    @access("say")
    async def template_list(self, interaction: discord.Interaction):
        rows = await self.bot.db.list_templates(interaction.guild.id)
        if not rows:
            await interaction.response.send_message(
                embed=embeds.info("Шаблонов пока нет. Сохрани первый из конструктора кнопкой 💾.",
                                  "💾 Шаблоны"),
                ephemeral=True,
            )
            return
        lines = [f"• **{r['name']}** — <@{r['author_id']}>, <t:{r['created_at']}:R>" for r in rows]
        await interaction.response.send_message(
            embed=embeds.info("\n".join(lines)[:4000], "💾 Шаблоны"), ephemeral=True
        )

    @template.command(name="delete", description="Удалить шаблон")
    @app_commands.describe(name="Название шаблона")
    @app_commands.autocomplete(name=template_names)
    @access("say")
    async def template_delete(self, interaction: discord.Interaction, name: str):
        removed = await self.bot.db.delete_template(interaction.guild.id, name.lower())
        message = (embeds.ok(f"Шаблон **{name}** удалён.")
                   if removed else embeds.err(f"Шаблон **{name}** не найден."))
        await interaction.response.send_message(embed=message, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Staff(bot))
