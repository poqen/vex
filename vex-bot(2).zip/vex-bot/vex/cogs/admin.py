"""Администрирование: доступ к командам по ролям (/perms), настройки (/config), логи, приветствие, /help."""
import discord
from discord import app_commands
from discord.ext import commands

from .. import config, embeds
from ..checks import admin_only

KEY_CHOICES = [
    app_commands.Choice(name=f"{key} — {desc}"[:100], value=key)
    for key, desc in config.COMMAND_KEYS.items()
]

DEFAULT_WELCOME = (
    "Привет, {user}! Добро пожаловать на **{server}**.\n"
    "Загляни в правила, а если хочешь вступить в клан — открой тикет."
)

# Разделы справки: (заголовок, [(команда, что делает, ключ доступа)])
HELP_SECTIONS = [
    ("🎫 Тикеты", [
        ("/ticket panel", "панель создания обращений", "ticket_admin"),
        ("/ticket setup", "категория, лог, лимит, удалять ли канал", "ticket_admin"),
        ("/ticket support add|remove|list", "роли поддержки", "ticket_admin"),
        ("/ticket type add|remove|list", "свои типы обращений", "ticket_admin"),
        ("/ticket blacklist add|remove|list", "кому запрещено открывать тикеты", "ticket_admin"),
        ("/ticket autoclose · archive", "автозакрытие и категория-архив", "ticket_admin"),
        ("/ticket reopen", "открыть закрытый тикет заново", "ticket_admin"),
        ("/ticket claim · unclaim · transfer", "взять, отпустить, передать", "поддержка"),
        ("/ticket priority · lock · unlock · move", "срочность, блокировка, перенос", "поддержка"),
        ("/ticket note · notes", "внутренние заметки", "поддержка"),
        ("/ticket add · remove · rename · close", "участники, имя канала, закрытие", "поддержка"),
        ("/ticket list · info · transcript · stats", "обзор, карточка, переписка, статистика",
         "ticket_manage"),
    ]),
    ("✉️ Эмбеды и сообщения", [
        ("/say embed", "конструктор: заголовок, автор, футер, поля, картинки, JSON", "say"),
        ("/say plain", "быстрый текст от имени бота", "say"),
        ("/say raw", "отправка готового JSON", "say"),
        ("/say edit", "править сообщение бота в конструкторе", "say"),
        ("/say template save|load|list|delete", "шаблоны эмбедов", "say"),
    ]),
    ("⚔️ Клан и вайпы", [
        ("/wipereact", "событие с кнопками «Приду / Не приду / Опоздаю»", "wipe"),
        ("/noreact", "кто не ответил на событие", "wipe"),
        ("/wipe stats", "топ по явке на вайпы", "wipe"),
        ("/roster", "состав клана страницами", "roster"),
        ("/nick set · show · clear", "карточка участника: ник, часы, часовой пояс", "всем"),
        ("/poll create · close · results", "голосование кнопками с живыми результатами", "poll"),
    ]),
    ("🛡️ Модерация", [
        ("/automod status · toggle", "автомодерация ссылок", "automod"),
        ("/automod allow · disallow · bypass · ignore_channel · punishment",
         "домены, исключения, наказание", "automod"),
        ("/role add · remove", "выдать и снять роль", "role"),
        ("/role allow · deny · allowed", "какие роли можно выдавать", "role_admin"),
        ("/autorole add · remove · list", "роли для новых участников и ботов", "autorole"),
    ]),
    ("⚙️ Настройка", [
        ("/perms grant · revoke · reset · list", "кто какими командами пользуется", "админ"),
        ("/config log_channel", "канал логов модерации", "админ"),
        ("/config welcome · welcome_off", "приветствие новых участников", "админ"),
        ("/config show", "текущие настройки сервера", "админ"),
        ("/help", "эта справка", "всем"),
    ]),
]


class Permissions(commands.Cog):
    perms = app_commands.Group(
        name="perms",
        description="Какие роли имеют доступ к каким командам бота",
        guild_only=True,
        default_permissions=discord.Permissions(administrator=True),
    )

    def __init__(self, bot):
        self.bot = bot

    @perms.command(name="grant", description="Дать роли доступ к группе команд")
    @app_commands.describe(command="Группа команд", role="Роль")
    @app_commands.choices(command=KEY_CHOICES)
    @admin_only()
    async def grant(self, interaction: discord.Interaction, command: app_commands.Choice[str],
                    role: discord.Role):
        added = await self.bot.db.add_target(interaction.guild.id, f"cmd:{command.value}", role.id)
        text = (f"{role.mention} теперь имеет доступ: **{command.value}**."
                if added else f"{role.mention} уже имеет доступ к **{command.value}**.")
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @perms.command(name="revoke", description="Забрать у роли доступ к группе команд")
    @app_commands.describe(command="Группа команд", role="Роль")
    @app_commands.choices(command=KEY_CHOICES)
    @admin_only()
    async def revoke(self, interaction: discord.Interaction, command: app_commands.Choice[str],
                     role: discord.Role):
        removed = await self.bot.db.remove_target(interaction.guild.id, f"cmd:{command.value}", role.id)
        text = (f"У {role.mention} больше нет доступа к **{command.value}**."
                if removed else f"У {role.mention} и не было доступа к **{command.value}**.")
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @perms.command(name="reset", description="Сбросить доступ группы команд (останутся только администраторы)")
    @app_commands.describe(command="Группа команд")
    @app_commands.choices(command=KEY_CHOICES)
    @admin_only()
    async def reset(self, interaction: discord.Interaction, command: app_commands.Choice[str]):
        await self.bot.db.clear_targets(interaction.guild.id, f"cmd:{command.value}")
        await interaction.response.send_message(
            embed=embeds.ok(f"Доступ к **{command.value}** сброшен — только администраторы."), ephemeral=True
        )

    @perms.command(name="list", description="Показать, кто к чему имеет доступ")
    @admin_only()
    async def list_perms(self, interaction: discord.Interaction):
        embed = embeds.make("🔐 Доступ к командам", "Администраторы имеют доступ ко всему.")
        for key, desc in config.COMMAND_KEYS.items():
            ids = await self.bot.db.get_targets(interaction.guild.id, f"cmd:{key}")
            roles = " ".join(f"<@&{i}>" for i in ids) or "*только администраторы*"
            embed.add_field(name=f"`{key}`", value=f"{desc}\n└ {roles}", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)


class ServerConfig(commands.Cog):
    config_group = app_commands.Group(
        name="config",
        description="Настройки бота на сервере",
        guild_only=True,
        default_permissions=discord.Permissions(administrator=True),
    )

    def __init__(self, bot):
        self.bot = bot

    # ---- команды
    @config_group.command(name="log_channel", description="Канал для логов модерации и действий бота")
    @app_commands.describe(channel="Приватный канал для модераторов")
    @admin_only()
    async def log_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        await self.bot.db.set_setting(interaction.guild.id, "mod_log", channel.id)
        await interaction.response.send_message(
            embed=embeds.ok(f"Логи будут приходить в {channel.mention}."), ephemeral=True
        )

    @config_group.command(name="welcome", description="Включить приветствие новых участников")
    @app_commands.describe(channel="Канал приветствий",
                           text="Текст. Можно {user}, {server}. Пусто — стандартный")
    @admin_only()
    async def welcome(self, interaction: discord.Interaction, channel: discord.TextChannel,
                      text: str | None = None):
        gid = interaction.guild.id
        await self.bot.db.set_setting(gid, "welcome_channel", channel.id)
        if text:
            await self.bot.db.set_setting(gid, "welcome_text", text.replace("\\n", "\n"))
        else:
            await self.bot.db.del_setting(gid, "welcome_text")
        await interaction.response.send_message(
            embed=embeds.ok(f"Приветствия включены в {channel.mention}."), ephemeral=True
        )

    @config_group.command(name="welcome_off", description="Выключить приветствие")
    @admin_only()
    async def welcome_off(self, interaction: discord.Interaction):
        await self.bot.db.del_setting(interaction.guild.id, "welcome_channel")
        await interaction.response.send_message(embed=embeds.ok("Приветствия выключены."), ephemeral=True)

    @config_group.command(name="show", description="Показать текущие настройки")
    @admin_only()
    async def show(self, interaction: discord.Interaction):
        gid = interaction.guild.id
        db = self.bot.db

        async def channel_of(key):
            value = await db.get_setting(gid, key)
            return f"<#{value}>" if value else "—"

        category = await db.get_setting(gid, "ticket_category")
        archive = await db.get_setting(gid, "ticket_archive")
        autoclose = await db.get_setting(gid, "ticket_autoclose", "0")
        delete_on_close = await db.get_setting(gid, "ticket_delete_on_close", "1")

        embed = embeds.make("⚙️ Настройки VEX")
        embed.add_field(name="Лог модерации", value=await channel_of("mod_log"), inline=True)
        embed.add_field(name="Лог тикетов", value=await channel_of("ticket_log"), inline=True)
        embed.add_field(name="Приветствия", value=await channel_of("welcome_channel"), inline=True)
        embed.add_field(name="Категория тикетов", value=f"<#{category}>" if category else "—", inline=True)
        embed.add_field(name="Архив тикетов", value=f"<#{archive}>" if archive else "—", inline=True)
        embed.add_field(name="После закрытия",
                        value="удалять канал" if delete_on_close == "1" else "в архив", inline=True)
        embed.add_field(name="Автозакрытие",
                        value=f"{autoclose} ч" if autoclose != "0" else "выключено", inline=True)
        embed.add_field(name="Часовой пояс", value=config.TIMEZONE, inline=True)
        embed.add_field(name="База данных", value=f"`{self.bot.db.path}`", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ---- события: приветствие и журнал входов/выходов
    @commands.Cog.listener()
    async def on_member_join(self, member):
        gid = member.guild.id
        log = embeds.make("📥 Участник зашёл", color=config.COLOR_OK)
        log.add_field(name="Участник", value=f"{member.mention} (`{member.id}`)", inline=True)
        log.add_field(name="Аккаунт создан", value=discord.utils.format_dt(member.created_at, "R"), inline=True)
        log.set_thumbnail(url=member.display_avatar.url)
        await self.bot.send_log(member.guild, log)

        channel_id = await self.bot.db.get_setting(gid, "welcome_channel")
        if not channel_id or member.bot:
            return
        channel = member.guild.get_channel(int(channel_id))
        if channel is None:
            return
        template = await self.bot.db.get_setting(gid, "welcome_text", DEFAULT_WELCOME)
        text = template.replace("{user}", member.mention).replace("{server}", member.guild.name)
        embed = embeds.make("👋 Добро пожаловать!", text)
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Участник №", value=str(member.guild.member_count), inline=True)
        try:
            await channel.send(embed=embed, allowed_mentions=discord.AllowedMentions(users=True))
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        log = embeds.make("📤 Участник вышел", color=config.COLOR_ERR)
        log.add_field(name="Участник", value=f"{member} (`{member.id}`)", inline=True)
        roles = [r.mention for r in member.roles if not r.is_default()]
        log.add_field(name="Роли", value=" ".join(roles)[:1000] or "—", inline=False)
        await self.bot.send_log(member.guild, log)


class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Что умеет VEX")
    async def help(self, interaction: discord.Interaction):
        embed = embeds.make(
            "🟣 VEX — управление кланом",
            "Тикеты, конструктор эмбедов, состав клана, вайп-события, роли и защита сервера.\n"
            "В скобках — ключ доступа: его выдают роли командой `/perms grant`.",
        )
        for title, rows in HELP_SECTIONS:
            lines = [f"`{command}`\n└ {what} *({key})*" for command, what, key in rows]
            embed.add_field(name=title, value="\n".join(lines)[:1024], inline=False)
        embed.set_footer(text=f"{config.FOOTER} • «поддержка» = роль из /ticket support add")
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Permissions(bot))
    await bot.add_cog(ServerConfig(bot))
    await bot.add_cog(Help(bot))
