"""Автомодерация: защита от нежелательных ссылок и инвайтов."""
import logging
import re
from datetime import timedelta
from time import time as now_ts

import discord
from discord import app_commands
from discord.ext import commands

from .. import config, embeds
from ..checks import access

log = logging.getLogger("vex")

TLDS = (
    "com|net|org|ru|su|ua|by|kz|gg|io|me|tv|xyz|ly|cc|info|biz|pro|club|online|site|link|"
    "store|shop|app|dev|fun|top|vip|ws|gl|gd"
)
URL_RE = re.compile(
    r"(?:https?://|www\.)[^\s<>()\[\]]+"
    r"|(?:discord\.gg|discord(?:app)?\.com/invite)/[^\s<>()\[\]]+"
    r"|\b(?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+(?:" + TLDS + r")\b(?:/[^\s<>()\[\]]*)?",
    re.IGNORECASE,
)
STRIKE_WINDOW = 10 * 60  # секунд: сколько «живёт» нарушение


def extract_host(link):
    host = re.sub(r"^(?:https?://)?(?:www\.)?", "", link.strip().lower())
    host = host.split("/")[0].split("?")[0].split("#")[0]
    host = host.split("@")[-1].split(":")[0]
    return host


def normalize_domain(text):
    return extract_host(text).strip(".")


def find_violation(content, allowed):
    """Возвращает первую запрещённую ссылку в тексте или None."""
    for match in URL_RE.finditer(content):
        raw = match.group(0)
        host = extract_host(raw)
        if not host:
            continue
        if host in ("discord.com", "discordapp.com") and "/channels/" in raw.lower():
            continue  # ссылки на сообщения Discord
        if any(host == d or host.endswith("." + d) for d in allowed):
            continue
        return raw
    return None


class AutoMod(commands.Cog):
    automod = app_commands.Group(
        name="automod", description="Автомодерация ссылок", guild_only=True
    )

    def __init__(self, bot):
        self.bot = bot
        self.strikes = {}  # (guild_id, user_id) -> [timestamps]

    # ---- данные
    async def allowed_domains(self, guild_id):
        rows = await self.bot.db.fetchall("SELECT domain FROM allowed_domains WHERE guild_id=?", (guild_id,))
        return set(config.DEFAULT_ALLOWED_DOMAINS) | {r["domain"] for r in rows}

    async def is_exempt(self, message):
        member = message.author
        perms = member.guild_permissions
        if perms.administrator or perms.manage_messages:
            return True
        guild_id = message.guild.id
        bypass = await self.bot.db.get_targets(guild_id, "automod_bypass")
        if any(role.id in bypass for role in member.roles):
            return True
        ignored = await self.bot.db.get_targets(guild_id, "automod_ignore_channel")
        return message.channel.id in ignored

    # ---- проверка сообщений
    async def check_message(self, message):
        if message.guild is None or message.author.bot or not message.content:
            return
        if not isinstance(message.author, discord.Member):
            return
        if not URL_RE.search(message.content):
            return  # дёшево отсекаем почти все сообщения без обращения к базе

        guild_id = message.guild.id
        if await self.bot.db.get_setting(guild_id, "automod_enabled", "1") == "0":
            return
        if await self.is_exempt(message):
            return
        link = find_violation(message.content, await self.allowed_domains(guild_id))
        if link is None:
            return
        await self.punish(message, link)

    async def punish(self, message, link):
        guild = message.guild
        member = message.author
        db = self.bot.db

        deleted = True
        try:
            await message.delete()
        except discord.NotFound:
            pass
        except discord.Forbidden:
            deleted = False

        max_strikes = int(await db.get_setting(guild.id, "automod_strikes", "3"))
        timeout_minutes = int(await db.get_setting(guild.id, "automod_timeout", "10"))
        key = (guild.id, member.id)
        now = now_ts()
        history = [t for t in self.strikes.get(key, []) if now - t < STRIKE_WINDOW] + [now]
        self.strikes[key] = history

        action = "Сообщение удалено" if deleted else "❗ Не удалось удалить (нет прав Manage Messages)"
        timed_out = False
        if len(history) >= max_strikes and timeout_minutes > 0:
            try:
                await member.timeout(timedelta(minutes=timeout_minutes), reason="VEX AutoMod: ссылки")
                timed_out = True
                self.strikes.pop(key, None)
                action += f" • тайм-аут на {timeout_minutes} мин."
            except (discord.Forbidden, discord.HTTPException):
                action += " • тайм-аут выдать не удалось (роль бота ниже участника)"

        try:
            warning = embeds.warn(
                f"{member.mention}, отправка ссылок здесь запрещена.\n"
                "Если ссылка нужна — напиши модераторам или открой тикет.",
                "Ссылка удалена",
            )
            if timed_out:
                warning.add_field(name="Наказание", value=f"Тайм-аут на {timeout_minutes} мин.")
            await message.channel.send(embed=warning, delete_after=10)
        except discord.HTTPException:
            pass

        log_embed = embeds.make("🛡️ AutoMod: нежелательная ссылка", color=config.COLOR_WARN)
        log_embed.add_field(name="Участник", value=f"{member.mention} (`{member.id}`)", inline=True)
        log_embed.add_field(name="Канал", value=message.channel.mention, inline=True)
        log_embed.add_field(name="Ссылка", value=f"`{link[:200]}`", inline=False)
        log_embed.add_field(name="Действие", value=action, inline=False)
        log_embed.add_field(name="Нарушений за 10 мин", value=str(len(history)), inline=True)
        await self.bot.send_log(guild, log_embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        await self.check_message(message)

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.content != after.content:
            await self.check_message(after)

    # ---- команды
    @automod.command(name="status", description="Текущие настройки автомодерации")
    @access("automod")
    async def status(self, interaction: discord.Interaction):
        gid = interaction.guild.id
        db = self.bot.db
        enabled = await db.get_setting(gid, "automod_enabled", "1") != "0"
        strikes = await db.get_setting(gid, "automod_strikes", "3")
        timeout = await db.get_setting(gid, "automod_timeout", "10")
        domains = sorted(await self.allowed_domains(gid))
        bypass = await db.get_targets(gid, "automod_bypass")
        ignored = await db.get_targets(gid, "automod_ignore_channel")
        embed = embeds.make("🛡️ Автомодерация ссылок")
        embed.add_field(name="Состояние", value="🟢 Включена" if enabled else "🔴 Выключена", inline=True)
        embed.add_field(name="Тайм-аут", value=f"после {strikes} нарушений • {timeout} мин.", inline=True)
        embed.add_field(name="Разрешённые домены", value="\n".join(f"`{d}`" for d in domains)[:1000] or "—",
                        inline=False)
        embed.add_field(name="Игнорируемые роли",
                        value=" ".join(f"<@&{r}>" for r in bypass) or "— (модераторы с Manage Messages и админы не проверяются)",
                        inline=False)
        embed.add_field(name="Игнорируемые каналы", value=" ".join(f"<#{c}>" for c in ignored) or "—",
                        inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @automod.command(name="toggle", description="Включить или выключить автомодерацию")
    @app_commands.describe(enabled="True — включить, False — выключить")
    @access("automod")
    async def toggle(self, interaction: discord.Interaction, enabled: bool):
        await self.bot.db.set_setting(interaction.guild.id, "automod_enabled", "1" if enabled else "0")
        text = "Автомодерация включена." if enabled else "Автомодерация выключена."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @automod.command(name="allow", description="Разрешить домен (например youtube.com)")
    @app_commands.describe(domain="Домен или ссылка")
    @access("automod")
    async def allow(self, interaction: discord.Interaction, domain: str):
        domain = normalize_domain(domain)
        if "." not in domain:
            await interaction.response.send_message(embed=embeds.err("Это не похоже на домен."), ephemeral=True)
            return
        changed = await self.bot.db.execute(
            "INSERT OR IGNORE INTO allowed_domains(guild_id, domain) VALUES(?,?)", (interaction.guild.id, domain)
        )
        text = f"`{domain}` разрешён (вместе с поддоменами)." if changed else f"`{domain}` уже разрешён."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @automod.command(name="disallow", description="Убрать домен из разрешённых")
    @app_commands.describe(domain="Домен или ссылка")
    @access("automod")
    async def disallow(self, interaction: discord.Interaction, domain: str):
        domain = normalize_domain(domain)
        changed = await self.bot.db.execute(
            "DELETE FROM allowed_domains WHERE guild_id=? AND domain=?", (interaction.guild.id, domain)
        )
        if changed:
            text = f"`{domain}` больше не разрешён."
        elif domain in config.DEFAULT_ALLOWED_DOMAINS:
            text = f"`{domain}` — встроенный домен, его можно изменить только в `vex/config.py`."
        else:
            text = f"`{domain}` не был в списке."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @automod.command(name="bypass", description="Роль, которую автомодерация не проверяет")
    @app_commands.describe(role="Роль", enabled="True — не проверять, False — снова проверять")
    @access("automod")
    async def bypass(self, interaction: discord.Interaction, role: discord.Role, enabled: bool = True):
        gid = interaction.guild.id
        if enabled:
            await self.bot.db.add_target(gid, "automod_bypass", role.id)
            text = f"{role.mention} теперь не проверяется."
        else:
            await self.bot.db.remove_target(gid, "automod_bypass", role.id)
            text = f"{role.mention} снова проверяется."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @automod.command(name="ignore_channel", description="Канал, где ссылки разрешены")
    @app_commands.describe(channel="Канал", enabled="True — разрешить ссылки, False — снова проверять")
    @access("automod")
    async def ignore_channel(self, interaction: discord.Interaction, channel: discord.TextChannel,
                             enabled: bool = True):
        gid = interaction.guild.id
        if enabled:
            await self.bot.db.add_target(gid, "automod_ignore_channel", channel.id)
            text = f"В {channel.mention} ссылки разрешены."
        else:
            await self.bot.db.remove_target(gid, "automod_ignore_channel", channel.id)
            text = f"В {channel.mention} ссылки снова проверяются."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @automod.command(name="punishment", description="Сколько нарушений до тайм-аута и на сколько минут")
    @app_commands.describe(strikes="Нарушений за 10 минут до тайм-аута",
                           timeout_minutes="Длительность тайм-аута в минутах (0 — не выдавать)")
    @access("automod")
    async def punishment(self, interaction: discord.Interaction, strikes: app_commands.Range[int, 1, 10],
                         timeout_minutes: app_commands.Range[int, 0, 1440]):
        gid = interaction.guild.id
        await self.bot.db.set_setting(gid, "automod_strikes", strikes)
        await self.bot.db.set_setting(gid, "automod_timeout", timeout_minutes)
        text = (f"После **{strikes}** нарушений за 10 минут — тайм-аут на **{timeout_minutes}** мин."
                if timeout_minutes else "Тайм-ауты отключены, ссылки только удаляются.")
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)


async def setup(bot):
    await bot.add_cog(AutoMod(bot))
