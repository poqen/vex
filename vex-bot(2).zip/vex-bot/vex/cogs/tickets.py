"""Тикеты: панель с меню, приватные каналы, приоритеты, заметки, транскрипты и оценки."""
import asyncio
import html as html_mod
import io
import logging
import re
import unicodedata
from datetime import datetime
from time import time as now_ts
from zoneinfo import ZoneInfo

import discord
from discord import app_commands
from discord.ext import commands, tasks

from .. import config, embeds
from ..checks import access, member_has_access

log = logging.getLogger("vex")
TZ = ZoneInfo(config.TIMEZONE)

# Приоритет задаёт цвет эмбеда и префикс имени канала.
PRIORITIES = {
    "low": ("🟢 Низкий", config.COLOR_OK),
    "normal": ("🔵 Обычный", config.COLOR_MAIN),
    "high": ("🟠 Высокий", config.COLOR_WARN),
    "urgent": ("🔴 Срочный", config.COLOR_ERR),
}
PRIORITY_CHOICES = [
    app_commands.Choice(name=label, value=key) for key, (label, _) in PRIORITIES.items()
]
FALLBACK_TYPE = {"key": "other", "slug": "ticket", "label": "Обращение", "emoji": "🎫",
                 "description": ""}
PAGE_SIZE = 15


# --------------------------------------------------------------------------- утилиты
def slugify(text):
    """'Вступление в клан' -> 'vstuplenie-v-klan' (имена каналов Discord любят латиницу)."""
    table = {
        "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh",
        "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o",
        "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "c",
        "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu",
        "я": "ya",
    }
    out = "".join(table.get(ch, ch) for ch in text.lower())
    out = unicodedata.normalize("NFKD", out).encode("ascii", "ignore").decode()
    out = re.sub(r"[^a-z0-9]+", "-", out).strip("-")
    return out[:20] or "ticket"


def safe_emoji(value):
    """Эмодзи из базы может оказаться мусором — тогда просто не показываем его."""
    if not value:
        return None
    try:
        return discord.PartialEmoji.from_str(value)
    except Exception:
        return None


def fmt_ts(epoch):
    """Unix-время -> '25.11.2026 19:30' в часовом поясе бота."""
    try:
        return datetime.fromtimestamp(int(epoch), TZ).strftime("%d.%m.%Y %H:%M")
    except (TypeError, ValueError, OSError):
        return "—"


def fmt_duration(seconds):
    """3725 -> '1 ч 2 мин'."""
    if not seconds:
        return "—"
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds} сек"
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    if days:
        return f"{days} д {hours} ч"
    if hours:
        return f"{hours} ч {minutes} мин"
    return f"{minutes} мин"


def priority_of(row):
    try:
        value = row["priority"] or "normal"
    except (IndexError, KeyError):
        value = "normal"
    return value if value in PRIORITIES else "normal"


def channel_name_for(slug, ticket_id, priority):
    return f"{config.PRIORITY_CHANNEL_PREFIX.get(priority, '')}{slug}-{ticket_id:04d}"


# --------------------------------------------------------------------------- эмбеды
def panel_embed(types, title=None, description=None):
    if description:
        text = description
    else:
        listing = "\n".join(f"{t['emoji']} **{t['label']}** — {t['description']}" for t in types)
        text = (
            "Нужна помощь или хочешь вступить в клан?\n"
            "Выбери тип обращения в меню ниже — для тебя создастся приватный канал, "
            "где с тобой свяжется администрация.\n\n" + listing
        )
    embed = embeds.make(title or "🎫 Центр поддержки", text)
    if not description:
        embed.add_field(
            name="ℹ️ Правила",
            value="• Один открытый тикет на человека\n• Пиши по делу и не спамь\n"
                  "• Не пингуй администрацию без причины",
            inline=False,
        )
    return embed


def ticket_embed(guild, row, type_info):
    priority = priority_of(row)
    label, color = PRIORITIES[priority]
    embed = embeds.make(
        f"{type_info['emoji']} Тикет #{row['id']:04d} — {type_info['label']}", color=color
    )
    embed.description = f">>> {row['reason']}"[:4000]
    embed.add_field(name="👤 Автор", value=f"<@{row['user_id']}>", inline=True)

    if row["status"] != "open":
        status = "⚫ Закрыт"
    elif row["locked"]:
        status = "🔇 Заблокирован — автор не может писать"
    elif row["claimed_by"]:
        status = f"🟡 В работе — <@{row['claimed_by']}>"
    else:
        status = "🟢 Ожидает ответа"
    embed.add_field(name="📌 Статус", value=status, inline=True)
    embed.add_field(name="🚦 Приоритет", value=label, inline=True)
    embed.add_field(name="🕒 Создан", value=f"<t:{row['created_at']}:R>", inline=True)
    member = guild.get_member(row["user_id"])
    if member:
        embed.set_thumbnail(url=member.display_avatar.url)
    return embed


# --------------------------------------------------------------------------- интерфейс
class TicketReasonModal(discord.ui.Modal):
    def __init__(self, cog, type_info):
        super().__init__(title=type_info["label"][:45])
        self.cog = cog
        self.type_info = type_info
        self.reason = discord.ui.TextInput(
            label="Опишите ваш вопрос",
            style=discord.TextStyle.paragraph,
            placeholder="Расскажи подробно: что нужно, ник в игре, возраст, часы в Rust и т.д.",
            max_length=1000,
            required=True,
        )
        self.add_item(self.reason)

    async def on_submit(self, interaction):
        await self.cog.create_ticket(interaction, self.type_info, str(self.reason))


class TicketSelect(discord.ui.Select):
    def __init__(self, types=None):
        types = types or config.TICKET_TYPES
        options = []
        for t in types[:25]:
            description = (t.get("description") or "")[:100] or None
            options.append(discord.SelectOption(
                label=t["label"][:100], value=t["key"],
                description=description, emoji=safe_emoji(t["emoji"]),
            ))
        super().__init__(
            placeholder="Выберите тип обращения…",
            options=options,
            min_values=1,
            max_values=1,
            custom_id="vex:ticket:select",
        )

    async def callback(self, interaction):
        cog = interaction.client.get_cog("Tickets")
        types = await cog.bot.db.get_ticket_types(interaction.guild.id)
        chosen = next((t for t in types if t["key"] == self.values[0]), None)
        if chosen is None:
            await interaction.response.send_message(
                embed=embeds.err("Этот тип обращения больше не доступен — обнови панель."),
                ephemeral=True,
            )
            return
        await interaction.response.send_modal(TicketReasonModal(cog, chosen))
        # сбрасываем выбор в меню, чтобы им можно было пользоваться снова
        try:
            await interaction.message.edit(view=TicketPanelView(types))
        except discord.HTTPException:
            pass


class TicketPanelView(discord.ui.View):
    def __init__(self, types=None):
        super().__init__(timeout=None)
        self.add_item(TicketSelect(types))


class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Закрыть", emoji="🔒", style=discord.ButtonStyle.danger,
                       custom_id="vex:ticket:close")
    async def close_button(self, interaction, button):
        await interaction.client.get_cog("Tickets").on_close_button(interaction)

    @discord.ui.button(label="Взять в работу", emoji="✋", style=discord.ButtonStyle.success,
                       custom_id="vex:ticket:claim")
    async def claim_button(self, interaction, button):
        await interaction.client.get_cog("Tickets").on_claim_button(interaction)

    @discord.ui.button(label="Транскрипт", emoji="📄", style=discord.ButtonStyle.secondary,
                       custom_id="vex:ticket:transcript")
    async def transcript_button(self, interaction, button):
        await interaction.client.get_cog("Tickets").on_transcript_button(interaction)

    @discord.ui.button(label="Заблокировать", emoji="🔇", style=discord.ButtonStyle.secondary,
                       custom_id="vex:ticket:lock")
    async def lock_button(self, interaction, button):
        await interaction.client.get_cog("Tickets").on_lock_button(interaction)


class ConfirmCloseView(discord.ui.View):
    def __init__(self, cog, channel):
        super().__init__(timeout=60)
        self.cog = cog
        self.channel = channel

    @discord.ui.button(label="Да, закрыть", emoji="🔒", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction, button):
        await interaction.response.edit_message(embed=embeds.warn("Закрываю тикет…"), view=None)
        await self.cog.close_ticket(self.channel, interaction.user)

    @discord.ui.button(label="Отмена", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        await interaction.response.edit_message(embed=embeds.info("Отменено."), view=None)


class RateCommentModal(discord.ui.Modal):
    def __init__(self, cog, ticket_id, score):
        super().__init__(title="Спасибо за оценку!")
        self.cog = cog
        self.ticket_id = ticket_id
        self.score = score
        self.comment = discord.ui.TextInput(
            label="Комментарий (необязательно)",
            style=discord.TextStyle.paragraph,
            placeholder="Что понравилось, а что можно сделать лучше?",
            required=False,
            max_length=500,
        )
        self.add_item(self.comment)

    async def on_submit(self, interaction):
        await self.cog.save_rating_comment(interaction, self.ticket_id, self.score,
                                           str(self.comment).strip())


class RateButton(discord.ui.DynamicItem[discord.ui.Button],
                 template=r"vex:rate:(?P<ticket>[0-9]+):(?P<score>[1-5])"):
    """Кнопка оценки в ЛС. Работает и после перезапуска бота — id разбирается из custom_id."""

    def __init__(self, ticket_id, score):
        self.ticket_id = ticket_id
        self.score = score
        super().__init__(
            discord.ui.Button(
                label=str(score),
                emoji="⭐",
                style=discord.ButtonStyle.secondary,
                custom_id=f"vex:rate:{ticket_id}:{score}",
            )
        )

    @classmethod
    async def from_custom_id(cls, interaction, item, match, /):
        return cls(int(match["ticket"]), int(match["score"]))

    async def callback(self, interaction):
        cog = interaction.client.get_cog("Tickets")
        if cog is None:
            return
        await cog.on_rate(interaction, self.ticket_id, self.score)


def rating_view(ticket_id):
    view = discord.ui.View(timeout=None)
    for score in range(1, 6):
        view.add_item(RateButton(ticket_id, score))
    return view


class PageView(discord.ui.View):
    """Простая листалка эмбедов — для /ticket list, /roster и других списков."""

    def __init__(self, pages, author_id):
        super().__init__(timeout=180)
        self.pages = pages
        self.index = 0
        self.author_id = author_id
        self._sync()

    def _sync(self):
        self.prev.disabled = self.index == 0
        self.next.disabled = self.index >= len(self.pages) - 1

    async def interaction_check(self, interaction):
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                embed=embeds.err("Это чужой список — вызови команду сам."), ephemeral=True
            )
            return False
        return True

    @discord.ui.button(emoji="⬅️", style=discord.ButtonStyle.secondary)
    async def prev(self, interaction, button):
        self.index = max(0, self.index - 1)
        self._sync()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    @discord.ui.button(emoji="➡️", style=discord.ButtonStyle.secondary)
    async def next(self, interaction, button):
        self.index = min(len(self.pages) - 1, self.index + 1)
        self._sync()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)


def paginate(items, per_page, title, build_line, color=config.COLOR_MAIN):
    """Режет список строк на страницы-эмбеды."""
    pages = []
    total = (len(items) - 1) // per_page + 1 if items else 1
    for start in range(0, max(len(items), 1), per_page):
        chunk = items[start:start + per_page]
        body = "\n".join(build_line(item) for item in chunk) or "—"
        page = embeds.make(title, body, color=color)
        page.set_footer(text=f"{config.FOOTER} • страница {len(pages) + 1} из {total}")
        pages.append(page)
    return pages


# --------------------------------------------------------------------------- модуль
class Tickets(commands.Cog):
    ticket = app_commands.Group(name="ticket", description="Система тикетов", guild_only=True)
    support = app_commands.Group(name="support", description="Роли поддержки", parent=ticket)
    blacklist = app_commands.Group(name="blacklist", description="Кому запрещено открывать тикеты",
                                   parent=ticket)
    type_group = app_commands.Group(name="type", description="Типы обращений на панели",
                                    parent=ticket)

    def __init__(self, bot):
        self.bot = bot
        self._open_channels = set()  # кэш, чтобы не дёргать базу на каждое сообщение

    async def cog_load(self):
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketControlView())
        self.bot.add_dynamic_items(RateButton)
        rows = await self.bot.db.fetchall(
            "SELECT channel_id FROM tickets WHERE status='open' AND channel_id != 0"
        )
        self._open_channels = {r["channel_id"] for r in rows}
        try:
            config.TRANSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
        except OSError:
            log.warning("Не удалось создать папку для транскриптов: %s", config.TRANSCRIPT_DIR)
        self.autoclose_loop.start()

    async def cog_unload(self):
        self.autoclose_loop.cancel()

    # ---- вспомогательное
    async def get_ticket(self, channel_id):
        return await self.bot.db.fetchone(
            "SELECT * FROM tickets WHERE channel_id=? AND status='open'", (channel_id,)
        )

    async def type_info(self, guild_id, key):
        types = await self.bot.db.get_ticket_types(guild_id)
        for t in types:
            if t["key"] == key:
                return t
        return dict(FALLBACK_TYPE, key=key, label=key.capitalize())

    async def is_staff(self, member):
        if not isinstance(member, discord.Member):
            return False
        if member.guild_permissions.administrator:
            return True
        support = await self.bot.db.get_targets(member.guild.id, "ticket_support")
        if any(role.id in support for role in member.roles):
            return True
        return await member_has_access(self.bot, member, "ticket_manage")

    async def reload_row(self, ticket_id):
        return await self.bot.db.fetchone("SELECT * FROM tickets WHERE id=?", (ticket_id,))

    async def refresh_panel(self, channel, row):
        """Перерисовывает шапку тикета (первое сообщение бота в канале)."""
        try:
            info = await self.type_info(row["guild_id"], row["type"])
            async for message in channel.history(limit=5, oldest_first=True):
                if message.author.id == self.bot.user.id and message.embeds:
                    await message.edit(embed=ticket_embed(channel.guild, row, info),
                                       view=TicketControlView())
                    return
        except discord.HTTPException:
            pass

    async def resolve_ticket(self, interaction, ticket_id=None):
        """Тикет по номеру или тикет текущего канала (в любом статусе)."""
        db = self.bot.db
        if ticket_id:
            return await db.fetchone(
                "SELECT * FROM tickets WHERE id=? AND guild_id=?",
                (ticket_id, interaction.guild.id),
            )
        return await db.fetchone(
            "SELECT * FROM tickets WHERE channel_id=? ORDER BY id DESC LIMIT 1",
            (interaction.channel.id,),
        )

    # ---- транскрипты
    async def collect_messages(self, channel):
        result = []
        async for message in channel.history(limit=None, oldest_first=True):
            result.append(message)
        return result

    def render_txt(self, guild, row, info, messages, notes):
        lines = [
            f"Тикет #{row['id']:04d} • {guild.name}",
            f"Тип: {info['label']}",
            f"Автор: {row['user_id']}",
            f"Приоритет: {PRIORITIES[priority_of(row)][0]}",
            "-" * 48,
        ]
        for message in messages:
            stamp = message.created_at.astimezone(TZ).strftime("%d.%m.%Y %H:%M")
            text = message.content or ""
            for embed in message.embeds:
                if embed.title:
                    text += f" [embed: {embed.title}]"
            for attachment in message.attachments:
                text += f" [файл: {attachment.url}]"
            lines.append(f"[{stamp}] {message.author}: {text}")
        if notes:
            lines.append("-" * 48)
            lines.append("Внутренние заметки поддержки:")
            for note in notes:
                lines.append(f"[{fmt_ts(note['created_at'])}] {note['author_id']}: {note['text']}")
        return "\n".join(lines).encode("utf-8")

    def render_html(self, guild, row, info, messages, notes):
        """Тёмная тема, аватары, время в часовом поясе бота."""
        esc = html_mod.escape
        title = f"Тикет #{row['id']:04d} — {info['label']}"
        parts = [
            "<!doctype html>", '<html lang="ru">', "<head>", '<meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1">',
            f"<title>{esc(title)}</title>", "<style>",
            "body{margin:0;background:#0f0a1f;color:#ede9fe;"
            "font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;font-size:15px}",
            ".wrap{max-width:860px;margin:0 auto;padding:24px 16px 64px}",
            "header{border:1px solid rgba(139,92,246,.4);background:rgba(139,92,246,.12);"
            "border-radius:14px;padding:18px 22px;margin-bottom:24px}",
            "h1{margin:0 0 .4rem;font-size:1.5rem;color:#c4b5fd}",
            ".meta{color:#a78bfa;font-size:.9rem;line-height:1.6}",
            ".msg{display:flex;gap:12px;padding:10px 12px;border-radius:10px}",
            ".msg:hover{background:rgba(139,92,246,.07)}",
            ".av{width:40px;height:40px;border-radius:50%;flex:0 0 40px;background:#2e1065}",
            ".body{min-width:0;flex:1}",
            ".name{font-weight:600;color:#c4b5fd}",
            ".time{color:#7c6aa8;font-size:.78rem;margin-left:8px}",
            ".text{white-space:pre-wrap;word-wrap:break-word;margin-top:2px}",
            ".att,.emb{display:block;margin-top:6px;font-size:.85rem;color:#a78bfa}",
            ".notes{margin-top:28px;border-top:1px solid rgba(139,92,246,.3);padding-top:16px}",
            ".note{background:rgba(245,158,11,.1);border-left:3px solid #f59e0b;"
            "padding:8px 12px;border-radius:0 8px 8px 0;margin-bottom:8px}",
            "a{color:#a78bfa}",
            "</style>", "</head>", "<body>", '<div class="wrap">', "<header>",
            f"<h1>{esc(title)}</h1>", '<div class="meta">',
            f"Сервер: {esc(guild.name)}<br>",
            f"Автор ID: {row['user_id']}<br>",
            f"Приоритет: {esc(PRIORITIES[priority_of(row)][0])}<br>",
            f"Открыт: {esc(fmt_ts(row['created_at']))}<br>",
            f"Сообщений: {len(messages)}",
            "</div>", "</header>",
        ]
        for message in messages:
            stamp = message.created_at.astimezone(TZ).strftime("%d.%m.%Y %H:%M")
            try:
                avatar = str(message.author.display_avatar.url)
            except AttributeError:
                avatar = ""
            parts.append('<div class="msg">')
            parts.append(f'<img class="av" src="{esc(avatar)}" alt="">')
            parts.append('<div class="body">')
            parts.append(
                f'<span class="name">{esc(str(message.author))}</span>'
                f'<span class="time">{esc(stamp)}</span>'
            )
            if message.content:
                parts.append(f'<div class="text">{esc(message.content)}</div>')
            for embed in message.embeds:
                head = embed.title or ""
                body = (embed.description or "")[:500]
                if head or body:
                    parts.append(f'<span class="emb">▌ {esc(head)} {esc(body)}</span>')
            for attachment in message.attachments:
                parts.append(
                    f'<a class="att" href="{esc(attachment.url)}">📎 {esc(attachment.filename)}</a>'
                )
            parts.append("</div></div>")

        if notes:
            parts.append('<div class="notes"><h2 style="color:#f59e0b;font-size:1.1rem">'
                         "🗒️ Внутренние заметки поддержки</h2>")
            for note in notes:
                parts.append(
                    f'<div class="note"><b>ID {note["author_id"]}</b>'
                    f'<span class="time">{esc(fmt_ts(note["created_at"]))}</span>'
                    f'<div class="text">{esc(note["text"])}</div></div>'
                )
            parts.append("</div>")

        parts.append("</div></body></html>")
        return "\n".join(parts).encode("utf-8")

    async def build_transcript(self, channel, row):
        """Собирает TXT и HTML, кладёт файлы в DATA_DIR/transcripts и запоминает путь."""
        info = await self.type_info(row["guild_id"], row["type"])
        notes = await self.bot.db.fetchall(
            "SELECT * FROM ticket_notes WHERE ticket_id=? ORDER BY id", (row["id"],)
        )
        messages = await self.collect_messages(channel)
        txt = self.render_txt(channel.guild, row, info, messages, notes)
        htm = self.render_html(channel.guild, row, info, messages, notes)

        base = f"ticket-{row['id']:04d}"
        try:
            config.TRANSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
            (config.TRANSCRIPT_DIR / f"{base}.txt").write_bytes(txt)
            (config.TRANSCRIPT_DIR / f"{base}.html").write_bytes(htm)
            await self.bot.db.execute(
                "UPDATE tickets SET transcript=? WHERE id=?",
                (str(config.TRANSCRIPT_DIR / f"{base}.html"), row["id"]),
            )
        except OSError:
            log.warning("Не удалось сохранить транскрипт тикета #%s", row["id"])
        return txt, htm, base

    # ---- создание
    async def create_ticket(self, interaction, type_info, reason):
        guild = interaction.guild
        user = interaction.user
        db = self.bot.db
        await interaction.response.defer(ephemeral=True)

        banned = await db.is_blacklisted(guild.id, user.id)
        if banned:
            why = banned["reason"] or "причина не указана"
            await interaction.followup.send(
                embed=embeds.err(f"Тебе запрещено открывать тикеты.\n**Причина:** {why}",
                                 "Доступ закрыт"),
                ephemeral=True,
            )
            return

        category_id = await db.get_setting(guild.id, "ticket_category")
        category = guild.get_channel(int(category_id)) if category_id else None
        if not isinstance(category, discord.CategoryChannel):
            await interaction.followup.send(
                embed=embeds.err("Тикеты ещё не настроены. Сообщи администрации."), ephemeral=True
            )
            return

        max_open = int(await db.get_setting(guild.id, "ticket_max_open", "1"))
        rows = await db.fetchall(
            "SELECT id, channel_id FROM tickets WHERE guild_id=? AND user_id=? AND status='open'",
            (guild.id, user.id),
        )
        live = []
        for row in rows:
            if guild.get_channel(row["channel_id"]):
                live.append(row)
            else:  # канал удалили вручную
                await db.execute(
                    "UPDATE tickets SET status='closed', closed_at=? WHERE id=?",
                    (int(now_ts()), row["id"]),
                )
                self._open_channels.discard(row["channel_id"])
        if len(live) >= max_open:
            await interaction.followup.send(
                embed=embeds.warn(f"У тебя уже есть открытый тикет: <#{live[0]['channel_id']}>"),
                ephemeral=True,
            )
            return

        support_ids = await db.get_targets(guild.id, "ticket_support")
        support_roles = [r for r in (guild.get_role(i) for i in support_ids) if r]

        created = int(now_ts())
        ticket_id = await db.insert(
            "INSERT INTO tickets(guild_id, user_id, type, reason, created_at, last_activity) "
            "VALUES(?,?,?,?,?,?)",
            (guild.id, user.id, type_info["key"], reason, created, created),
        )

        member_perms = discord.PermissionOverwrite(
            view_channel=True, send_messages=True, read_message_history=True,
            attach_files=True, embed_links=True,
        )
        staff_perms = discord.PermissionOverwrite(
            view_channel=True, send_messages=True, read_message_history=True,
            attach_files=True, embed_links=True, manage_messages=True,
        )
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: member_perms,
            guild.me: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, manage_channels=True, manage_messages=True,
                embed_links=True, attach_files=True, read_message_history=True,
            ),
        }
        for role in support_roles:
            overwrites[role] = staff_perms

        slug = type_info.get("slug") or slugify(type_info["label"])
        try:
            channel = await guild.create_text_channel(
                name=channel_name_for(slug, ticket_id, "normal"),
                category=category,
                overwrites=overwrites,
                topic=f"Тикет #{ticket_id:04d} • {user} ({user.id})",
                reason=f"Тикет от {user}",
            )
        except (discord.Forbidden, discord.HTTPException):
            await db.execute("DELETE FROM tickets WHERE id=?", (ticket_id,))
            await interaction.followup.send(
                embed=embeds.err("Не удалось создать канал. Проверь права бота (Manage Channels)."),
                ephemeral=True,
            )
            return

        await db.execute("UPDATE tickets SET channel_id=? WHERE id=?", (channel.id, ticket_id))
        self._open_channels.add(channel.id)
        row = await self.reload_row(ticket_id)

        pings = " ".join([user.mention] + [r.mention for r in support_roles])
        await channel.send(
            content=pings,
            embed=ticket_embed(guild, row, type_info),
            view=TicketControlView(),
            allowed_mentions=discord.AllowedMentions(users=True, roles=True),
        )
        await interaction.followup.send(
            embed=embeds.ok(f"Тикет создан: {channel.mention}", "Обращение открыто"), ephemeral=True
        )

    # ---- кнопки внутри тикета
    async def on_close_button(self, interaction):
        row = await self.get_ticket(interaction.channel.id)
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Этот канал не является открытым тикетом."), ephemeral=True
            )
            return
        if not (interaction.user.id == row["user_id"] or await self.is_staff(interaction.user)):
            await interaction.response.send_message(
                embed=embeds.err("Закрыть тикет может его автор или поддержка."), ephemeral=True
            )
            return
        await interaction.response.send_message(
            embed=embeds.warn("Закрыть этот тикет? Переписка сохранится файлом в лог-канале."),
            view=ConfirmCloseView(self, interaction.channel),
            ephemeral=True,
        )

    async def on_claim_button(self, interaction):
        row = await self.get_ticket(interaction.channel.id)
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Этот канал не является открытым тикетом."), ephemeral=True
            )
            return
        if not await self.is_staff(interaction.user):
            await interaction.response.send_message(
                embed=embeds.err("Брать тикеты в работу может только поддержка."), ephemeral=True
            )
            return
        if row["claimed_by"]:
            await interaction.response.send_message(
                embed=embeds.warn(f"Тикет уже ведёт <@{row['claimed_by']}>."), ephemeral=True
            )
            return
        await self.bot.db.execute(
            "UPDATE tickets SET claimed_by=? WHERE id=?", (interaction.user.id, row["id"])
        )
        row = await self.reload_row(row["id"])
        info = await self.type_info(row["guild_id"], row["type"])
        await interaction.response.edit_message(
            embed=ticket_embed(interaction.guild, row, info), view=TicketControlView()
        )
        await interaction.channel.send(
            embed=embeds.info(f"✋ {interaction.user.mention} взял(а) тикет в работу."),
            allowed_mentions=discord.AllowedMentions.none(),
        )

    async def on_transcript_button(self, interaction):
        row = await self.bot.db.fetchone(
            "SELECT * FROM tickets WHERE channel_id=? ORDER BY id DESC LIMIT 1",
            (interaction.channel.id,),
        )
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Этот канал не связан с тикетом."), ephemeral=True
            )
            return
        if not await self.is_staff(interaction.user):
            await interaction.response.send_message(
                embed=embeds.err("Транскрипт доступен только поддержке."), ephemeral=True
            )
            return
        await interaction.response.defer(ephemeral=True)
        _, htm, base = await self.build_transcript(interaction.channel, row)
        await interaction.followup.send(
            embed=embeds.ok(f"Транскрипт тикета #{row['id']:04d}."),
            file=discord.File(io.BytesIO(htm), filename=f"{base}.html"),
            ephemeral=True,
        )

    async def on_lock_button(self, interaction):
        row = await self.get_ticket(interaction.channel.id)
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Этот канал не является открытым тикетом."), ephemeral=True
            )
            return
        if not await self.is_staff(interaction.user):
            await interaction.response.send_message(
                embed=embeds.err("Блокировать тикет может только поддержка."), ephemeral=True
            )
            return
        new_state = not bool(row["locked"])
        await self.set_lock(interaction.channel, row, new_state)
        row = await self.reload_row(row["id"])
        info = await self.type_info(row["guild_id"], row["type"])
        await interaction.response.edit_message(
            embed=ticket_embed(interaction.guild, row, info), view=TicketControlView()
        )
        text = ("🔇 Тикет заблокирован — автор пока не может писать."
                if new_state else "🔊 Тикет разблокирован — автор снова может писать.")
        await interaction.channel.send(embed=embeds.info(text))

    async def set_lock(self, channel, row, locked):
        member = channel.guild.get_member(row["user_id"])
        if member:
            try:
                await channel.set_permissions(
                    member, view_channel=True, read_message_history=True,
                    send_messages=not locked, attach_files=not locked, embed_links=not locked,
                )
            except discord.HTTPException:
                pass
        await self.bot.db.execute(
            "UPDATE tickets SET locked=? WHERE id=?", (int(locked), row["id"])
        )

    # ---- оценка качества поддержки
    async def on_rate(self, interaction, ticket_id, score):
        row = await self.reload_row(ticket_id)
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Этот тикет больше не существует."), ephemeral=True
            )
            return
        if interaction.user.id != row["user_id"]:
            await interaction.response.send_message(
                embed=embeds.err("Оценить тикет может только его автор."), ephemeral=True
            )
            return
        await self.bot.db.execute("UPDATE tickets SET rating=? WHERE id=?", (score, ticket_id))
        await interaction.response.send_modal(RateCommentModal(self, ticket_id, score))

    async def save_rating_comment(self, interaction, ticket_id, score, comment):
        await self.bot.db.execute(
            "UPDATE tickets SET rating_comment=? WHERE id=?", (comment or None, ticket_id)
        )
        row = await self.reload_row(ticket_id)
        stars = "⭐" * score
        done = embeds.ok(f"Твоя оценка: {stars} ({score}/5)\nСпасибо, это помогает нам стать лучше!",
                         "Оценка принята")
        try:
            await interaction.response.edit_message(embed=done, view=None)
        except discord.HTTPException:
            try:
                await interaction.followup.send(embed=done, ephemeral=True)
            except discord.HTTPException:
                pass

        guild = self.bot.get_guild(row["guild_id"]) if row else None
        if guild is None:
            return
        info = await self.type_info(guild.id, row["type"])
        report = embeds.make(f"⭐ Оценка тикета #{ticket_id:04d}",
                             color=config.COLOR_OK if score >= 4 else config.COLOR_WARN)
        report.add_field(name="Оценка", value=f"{stars} ({score}/5)", inline=True)
        report.add_field(name="Автор", value=f"<@{row['user_id']}>", inline=True)
        report.add_field(name="Тип", value=info["label"], inline=True)
        if row["claimed_by"]:
            report.add_field(name="Вёл", value=f"<@{row['claimed_by']}>", inline=True)
        if comment:
            report.add_field(name="Комментарий", value=comment[:1000], inline=False)
        await self.bot.send_log(guild, report, key="ticket_log")

    # ---- закрытие
    async def close_ticket(self, channel, closer, reason=None):
        row = await self.get_ticket(channel.id)
        if row is None:
            return
        guild = channel.guild
        db = self.bot.db
        closed_at = int(now_ts())
        await db.execute(
            "UPDATE tickets SET status='closed', closed_at=?, closed_by=?, close_reason=? WHERE id=?",
            (closed_at, getattr(closer, "id", None), reason, row["id"]),
        )
        self._open_channels.discard(channel.id)
        row = await self.reload_row(row["id"])
        info = await self.type_info(guild.id, row["type"])
        _, htm, base = await self.build_transcript(channel, row)

        note_count = await db.fetchone(
            "SELECT COUNT(*) AS n FROM ticket_notes WHERE ticket_id=?", (row["id"],)
        )
        entry = embeds.make(f"🔒 Тикет #{row['id']:04d} закрыт")
        entry.add_field(name="Автор", value=f"<@{row['user_id']}>", inline=True)
        entry.add_field(name="Закрыл", value=getattr(closer, "mention", str(closer)), inline=True)
        if row["claimed_by"]:
            entry.add_field(name="Вёл", value=f"<@{row['claimed_by']}>", inline=True)
        entry.add_field(name="Тип", value=info["label"], inline=True)
        entry.add_field(name="Приоритет", value=PRIORITIES[priority_of(row)][0], inline=True)
        entry.add_field(name="Открыт", value=f"<t:{row['created_at']}:f>", inline=True)
        entry.add_field(name="В работе", value=fmt_duration(closed_at - row["created_at"]),
                        inline=True)
        if note_count and note_count["n"]:
            entry.add_field(name="Заметок", value=str(note_count["n"]), inline=True)
        if reason:
            entry.add_field(name="Причина закрытия", value=reason[:1000], inline=False)
        await self.bot.send_log(
            guild, entry, key="ticket_log",
            file=discord.File(io.BytesIO(htm), filename=f"{base}.html"),
        )

        author = guild.get_member(row["user_id"])
        if author:
            try:
                dm = embeds.make(f"🔒 Твой тикет #{row['id']:04d} закрыт",
                                 f"Сервер: **{guild.name}**")
                if reason:
                    dm.add_field(name="Причина", value=reason[:1000], inline=False)
                dm.add_field(name="Оцени работу поддержки",
                             value="Нажми на звёзды ниже — это займёт пару секунд.", inline=False)
                await author.send(
                    embed=dm,
                    file=discord.File(io.BytesIO(htm), filename=f"{base}.html"),
                    view=rating_view(row["id"]),
                )
            except discord.HTTPException:
                pass  # личные сообщения закрыты

        delete_on_close = (await db.get_setting(guild.id, "ticket_delete_on_close", "1")) == "1"
        archive_id = await db.get_setting(guild.id, "ticket_archive")
        archive = guild.get_channel(int(archive_id)) if archive_id else None

        if not delete_on_close and isinstance(archive, discord.CategoryChannel):
            try:
                await channel.send(embed=embeds.warn("Тикет закрыт и перенесён в архив."))
                if author:
                    await channel.set_permissions(
                        author, view_channel=True, read_message_history=True, send_messages=False
                    )
                await channel.edit(category=archive, name=f"closed-{row['id']:04d}",
                                   reason=f"Тикет закрыт: {closer}")
            except discord.HTTPException:
                log.warning("Не удалось отправить тикет #%s в архив", row["id"])
            return

        try:
            await channel.send(embed=embeds.warn("Тикет закрыт. Канал будет удалён через 5 секунд."))
        except discord.HTTPException:
            pass
        await asyncio.sleep(5)
        try:
            await channel.delete(reason=f"Тикет закрыт: {closer}")
        except discord.HTTPException:
            pass

    # ---- фоновое автозакрытие
    @tasks.loop(minutes=10)
    async def autoclose_loop(self):
        try:
            rows = await self.bot.db.fetchall(
                "SELECT * FROM tickets WHERE status='open' AND channel_id != 0"
            )
            now = int(now_ts())
            hours_cache = {}
            for row in rows:
                gid = row["guild_id"]
                if gid not in hours_cache:
                    try:
                        hours_cache[gid] = int(
                            await self.bot.db.get_setting(gid, "ticket_autoclose", "0")
                        )
                    except (TypeError, ValueError):
                        hours_cache[gid] = 0
                hours = hours_cache[gid]
                if hours <= 0:
                    continue
                last = row["last_activity"] or row["created_at"]
                if now - last < hours * 3600:
                    continue
                guild = self.bot.get_guild(gid)
                channel = guild.get_channel(row["channel_id"]) if guild else None
                if channel is None:
                    await self.bot.db.execute(
                        "UPDATE tickets SET status='closed', closed_at=? WHERE id=?", (now, row["id"])
                    )
                    self._open_channels.discard(row["channel_id"])
                    continue
                await self.close_ticket(channel, guild.me, reason="Автозакрытие: нет активности")
        except Exception:  # цикл не должен умирать из-за одной ошибки
            log.exception("Ошибка в цикле автозакрытия тикетов")

    @autoclose_loop.before_loop
    async def before_autoclose_loop(self):
        await self.bot.wait_until_ready()

    # ---- активность в тикете
    @commands.Cog.listener()
    async def on_message(self, message):
        if message.guild is None or message.author.bot:
            return
        if message.channel.id not in self._open_channels:
            return
        row = await self.bot.db.fetchone(
            "SELECT * FROM tickets WHERE channel_id=? AND status='open'", (message.channel.id,)
        )
        if row is None:
            self._open_channels.discard(message.channel.id)
            return
        now = int(now_ts())
        first_reply = (
            row["first_reply_at"] is None
            and message.author.id != row["user_id"]
            and await self.is_staff(message.author)
        )
        if first_reply:
            await self.bot.db.execute(
                "UPDATE tickets SET last_activity=?, first_reply_at=? WHERE id=?",
                (now, now, row["id"]),
            )
        else:
            await self.bot.db.execute(
                "UPDATE tickets SET last_activity=? WHERE id=?", (now, row["id"])
            )

    # ---- команды администрации
    @ticket.command(name="panel", description="Отправить панель создания тикетов")
    @app_commands.describe(
        channel="Куда отправить панель (по умолчанию — текущий канал)",
        title="Свой заголовок панели",
        description="Свой текст панели (\\n — перенос строки)",
    )
    @access("ticket_admin")
    async def panel(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None,
                    title: str | None = None, description: str | None = None):
        channel = channel or interaction.channel
        if not isinstance(channel, discord.TextChannel):
            await interaction.response.send_message(
                embed=embeds.err("Панель можно отправить только в текстовый канал."), ephemeral=True
            )
            return
        types = await self.bot.db.get_ticket_types(interaction.guild.id)
        text = description.replace("\\n", "\n") if description else None
        try:
            await channel.send(embed=panel_embed(types, title, text), view=TicketPanelView(types))
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=embeds.err(f"У меня нет прав писать в {channel.mention}."), ephemeral=True
            )
            return
        note = f"Панель отправлена в {channel.mention}."
        if not await self.bot.db.get_setting(interaction.guild.id, "ticket_category"):
            note += "\n⚠️ Категория для тикетов ещё не задана — выполни `/ticket setup`."
        await interaction.response.send_message(embed=embeds.ok(note), ephemeral=True)

    @ticket.command(name="setup", description="Настроить категорию, лог-канал и лимит тикетов")
    @app_commands.describe(
        category="Категория, где будут создаваться тикеты",
        log_channel="Канал для транскриптов закрытых тикетов",
        max_open="Сколько тикетов одновременно может быть у одного человека",
        delete_on_close="Удалять канал после закрытия (иначе — переносить в архив)",
    )
    @access("ticket_admin")
    async def setup_cmd(self, interaction: discord.Interaction, category: discord.CategoryChannel,
                        log_channel: discord.TextChannel | None = None,
                        max_open: app_commands.Range[int, 1, 5] = 1,
                        delete_on_close: bool = True):
        gid = interaction.guild.id
        await self.bot.db.set_setting(gid, "ticket_category", category.id)
        await self.bot.db.set_setting(gid, "ticket_max_open", max_open)
        await self.bot.db.set_setting(gid, "ticket_delete_on_close", int(delete_on_close))
        lines = [f"Категория: **{category.name}**", f"Лимит открытых тикетов: **{max_open}**"]
        if log_channel:
            await self.bot.db.set_setting(gid, "ticket_log", log_channel.id)
            lines.append(f"Лог тикетов: {log_channel.mention}")
        if delete_on_close:
            lines.append("После закрытия канал **удаляется** через 5 секунд.")
        else:
            lines.append("После закрытия канал **переносится в архив** "
                         "(категорию задаёт `/ticket archive`).")
        await interaction.response.send_message(
            embed=embeds.ok("\n".join(lines), "Тикеты настроены"), ephemeral=True
        )

    @ticket.command(name="autoclose", description="Автозакрытие тикетов без активности (0 — выключить)")
    @app_commands.describe(hours="Через сколько часов тишины закрывать тикет. 0 — не закрывать")
    @access("ticket_admin")
    async def autoclose(self, interaction: discord.Interaction,
                        hours: app_commands.Range[int, 0, 720]):
        await self.bot.db.set_setting(interaction.guild.id, "ticket_autoclose", hours)
        text = (f"Тикеты без активности будут закрываться через **{hours} ч**."
                if hours else "Автозакрытие выключено.")
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @ticket.command(name="archive", description="Категория-архив для закрытых тикетов")
    @app_commands.describe(category="Куда переносить каналы закрытых тикетов")
    @access("ticket_admin")
    async def archive(self, interaction: discord.Interaction, category: discord.CategoryChannel):
        gid = interaction.guild.id
        await self.bot.db.set_setting(gid, "ticket_archive", category.id)
        lines = [f"Архив тикетов: **{category.name}**"]
        if (await self.bot.db.get_setting(gid, "ticket_delete_on_close", "1")) == "1":
            lines.append("⚠️ Сейчас каналы удаляются при закрытии. Чтобы они попадали в архив, "
                         "выполни `/ticket setup` с `delete_on_close: False`.")
        await interaction.response.send_message(embed=embeds.ok("\n".join(lines)), ephemeral=True)

    # ---- роли поддержки
    @support.command(name="add", description="Добавить роль поддержки (видит и ведёт все тикеты)")
    @app_commands.describe(role="Роль модераторов/поддержки")
    @access("ticket_admin")
    async def support_add(self, interaction: discord.Interaction, role: discord.Role):
        added = await self.bot.db.add_target(interaction.guild.id, "ticket_support", role.id)
        text = f"{role.mention} теперь видит новые тикеты." if added else f"{role.mention} уже в списке."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @support.command(name="remove", description="Убрать роль поддержки")
    @app_commands.describe(role="Роль, которую нужно убрать")
    @access("ticket_admin")
    async def support_remove(self, interaction: discord.Interaction, role: discord.Role):
        removed = await self.bot.db.remove_target(interaction.guild.id, "ticket_support", role.id)
        text = f"{role.mention} убрана из поддержки." if removed else f"{role.mention} не была в списке."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @support.command(name="list", description="Показать роли поддержки")
    @access("ticket_admin")
    async def support_list(self, interaction: discord.Interaction):
        ids = await self.bot.db.get_targets(interaction.guild.id, "ticket_support")
        text = "\n".join(f"• <@&{i}>" for i in ids) or "Роли не заданы — тикеты видят только администраторы."
        await interaction.response.send_message(
            embed=embeds.info(text, "🛠️ Роли поддержки"), ephemeral=True
        )

    # ---- типы обращений
    @type_group.command(name="add", description="Добавить или изменить тип обращения")
    @app_commands.describe(key="Короткий ключ (латиницей, без пробелов)", label="Название в меню",
                           emoji="Эмодзи", description="Подсказка под названием")
    @access("ticket_admin")
    async def type_add(self, interaction: discord.Interaction,
                       key: app_commands.Range[str, 1, 32],
                       label: app_commands.Range[str, 1, 80],
                       emoji: str = "🎫",
                       description: app_commands.Range[str, 1, 100] = ""):
        clean_key = slugify(key)
        types = await self.bot.db.get_ticket_types(interaction.guild.id)
        if len(types) >= 25 and clean_key not in {t["key"] for t in types}:
            await interaction.response.send_message(
                embed=embeds.err("В меню Discord помещается максимум 25 типов обращений."),
                ephemeral=True,
            )
            return
        await self.bot.db.add_ticket_type(
            interaction.guild.id, clean_key, label, emoji or "🎫", description,
            slugify(label), len(types),
        )
        await interaction.response.send_message(
            embed=embeds.ok(f"{emoji} **{label}** (`{clean_key}`) сохранён.\n"
                            "Отправь панель заново (`/ticket panel`), чтобы меню обновилось."),
            ephemeral=True,
        )

    @type_group.command(name="remove", description="Удалить тип обращения")
    @app_commands.describe(key="Ключ типа (см. /ticket type list)")
    @access("ticket_admin")
    async def type_remove(self, interaction: discord.Interaction, key: str):
        clean_key = slugify(key)
        removed = await self.bot.db.remove_ticket_type(interaction.guild.id, clean_key)
        if removed:
            message = embeds.ok(f"Тип `{clean_key}` удалён. Отправь панель заново (`/ticket panel`).")
        else:
            message = embeds.err(f"Тип `{clean_key}` не найден.")
        await interaction.response.send_message(embed=message, ephemeral=True)

    @type_group.command(name="list", description="Показать типы обращений сервера")
    @access("ticket_admin")
    async def type_list(self, interaction: discord.Interaction):
        types = await self.bot.db.get_ticket_types(interaction.guild.id)
        lines = [f"{t['emoji']} **{t['label']}** — `{t['key']}`\n└ {t['description'] or '—'}"
                 for t in types]
        await interaction.response.send_message(
            embed=embeds.info("\n".join(lines)[:4000], "🗂️ Типы обращений"), ephemeral=True
        )

    # ---- чёрный список
    @blacklist.command(name="add", description="Запретить участнику открывать тикеты")
    @app_commands.describe(user="Кому запретить", reason="Причина (покажем ему при попытке)")
    @access("ticket_admin")
    async def blacklist_add(self, interaction: discord.Interaction, user: discord.Member,
                            reason: str | None = None):
        await self.bot.db.add_blacklist(interaction.guild.id, user.id, reason, interaction.user.id)
        entry = embeds.make("🚫 Запрет на тикеты", color=config.COLOR_ERR)
        entry.add_field(name="Участник", value=f"{user.mention} (`{user.id}`)", inline=True)
        entry.add_field(name="Выдал", value=interaction.user.mention, inline=True)
        entry.add_field(name="Причина", value=reason or "—", inline=False)
        await self.bot.send_log(interaction.guild, entry, key="ticket_log")
        await interaction.response.send_message(
            embed=embeds.ok(f"{user.mention} больше не может открывать тикеты."), ephemeral=True
        )

    @blacklist.command(name="remove", description="Вернуть участнику возможность открывать тикеты")
    @app_commands.describe(user="Кого разблокировать")
    @access("ticket_admin")
    async def blacklist_remove(self, interaction: discord.Interaction, user: discord.Member):
        removed = await self.bot.db.remove_blacklist(interaction.guild.id, user.id)
        text = (f"{user.mention} снова может открывать тикеты."
                if removed else f"{user.mention} и не был в чёрном списке.")
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @blacklist.command(name="list", description="Кому запрещено открывать тикеты")
    @access("ticket_admin")
    async def blacklist_list(self, interaction: discord.Interaction):
        rows = await self.bot.db.list_blacklist(interaction.guild.id)
        if not rows:
            await interaction.response.send_message(
                embed=embeds.info("Чёрный список пуст.", "🚫 Запрет на тикеты"), ephemeral=True
            )
            return
        lines = [f"• <@{r['user_id']}> — {r['reason'] or 'без причины'} (<t:{r['added_at']}:R>)"
                 for r in rows]
        await interaction.response.send_message(
            embed=embeds.info("\n".join(lines)[:4000], "🚫 Запрет на тикеты"), ephemeral=True
        )

    # ---- команды внутри тикета
    async def _staff_ticket(self, interaction):
        """Возвращает строку тикета, если команда вызвана поддержкой в открытом тикете."""
        row = await self.get_ticket(interaction.channel.id)
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Эту команду нужно вызывать внутри открытого тикета."), ephemeral=True
            )
            return None
        if not await self.is_staff(interaction.user):
            await interaction.response.send_message(
                embed=embeds.err("Команда доступна только поддержке."), ephemeral=True
            )
            return None
        return row

    @ticket.command(name="add", description="Добавить участника в этот тикет")
    @app_commands.describe(user="Кого добавить")
    async def add(self, interaction: discord.Interaction, user: discord.Member):
        if await self._staff_ticket(interaction) is None:
            return
        await interaction.channel.set_permissions(
            user, view_channel=True, send_messages=True, read_message_history=True, attach_files=True
        )
        await interaction.response.send_message(embed=embeds.ok(f"{user.mention} добавлен(а) в тикет."))

    @ticket.command(name="remove", description="Убрать участника из этого тикета")
    @app_commands.describe(user="Кого убрать")
    async def remove(self, interaction: discord.Interaction, user: discord.Member):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        if user.id == row["user_id"]:
            await interaction.response.send_message(
                embed=embeds.err("Автора тикета убрать нельзя — закрой тикет."), ephemeral=True
            )
            return
        await interaction.channel.set_permissions(user, overwrite=None)
        await interaction.response.send_message(embed=embeds.ok(f"{user.mention} убран(а) из тикета."))

    @ticket.command(name="rename", description="Переименовать канал тикета")
    @app_commands.describe(name="Новое название")
    async def rename(self, interaction: discord.Interaction, name: app_commands.Range[str, 1, 80]):
        if await self._staff_ticket(interaction) is None:
            return
        await interaction.channel.edit(name=name)
        await interaction.response.send_message(embed=embeds.ok("Канал переименован."), ephemeral=True)

    @ticket.command(name="move", description="Перенести тикет в другую категорию")
    @app_commands.describe(category="Куда перенести канал")
    async def move(self, interaction: discord.Interaction, category: discord.CategoryChannel):
        if await self._staff_ticket(interaction) is None:
            return
        try:
            await interaction.channel.edit(category=category, reason=f"Перенос: {interaction.user}")
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=embeds.err("Нет прав переносить этот канал."), ephemeral=True
            )
            return
        await interaction.response.send_message(
            embed=embeds.ok(f"Тикет перенесён в **{category.name}**.")
        )

    @ticket.command(name="claim", description="Взять тикет в работу")
    async def claim(self, interaction: discord.Interaction):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        if row["claimed_by"] and row["claimed_by"] != interaction.user.id:
            await interaction.response.send_message(
                embed=embeds.warn(f"Тикет уже ведёт <@{row['claimed_by']}>. "
                                  "Используй `/ticket transfer`, чтобы передать его."),
                ephemeral=True,
            )
            return
        await self.bot.db.execute(
            "UPDATE tickets SET claimed_by=? WHERE id=?", (interaction.user.id, row["id"])
        )
        row = await self.reload_row(row["id"])
        await self.refresh_panel(interaction.channel, row)
        await interaction.response.send_message(
            embed=embeds.ok(f"✋ {interaction.user.mention} ведёт этот тикет."),
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @ticket.command(name="unclaim", description="Отпустить тикет")
    async def unclaim(self, interaction: discord.Interaction):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        if not row["claimed_by"]:
            await interaction.response.send_message(
                embed=embeds.warn("Этот тикет никто не ведёт."), ephemeral=True
            )
            return
        await self.bot.db.execute("UPDATE tickets SET claimed_by=NULL WHERE id=?", (row["id"],))
        row = await self.reload_row(row["id"])
        await self.refresh_panel(interaction.channel, row)
        await interaction.response.send_message(
            embed=embeds.ok(f"🖐️ {interaction.user.mention} отпустил(а) тикет — он снова свободен."),
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @ticket.command(name="transfer", description="Передать тикет другому сотруднику")
    @app_commands.describe(user="Кому передать")
    async def transfer(self, interaction: discord.Interaction, user: discord.Member):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        if not await self.is_staff(user):
            await interaction.response.send_message(
                embed=embeds.err(f"{user.mention} не входит в поддержку."), ephemeral=True
            )
            return
        await self.bot.db.execute("UPDATE tickets SET claimed_by=? WHERE id=?", (user.id, row["id"]))
        row = await self.reload_row(row["id"])
        await self.refresh_panel(interaction.channel, row)
        await interaction.channel.set_permissions(
            user, view_channel=True, send_messages=True, read_message_history=True, attach_files=True
        )
        await interaction.response.send_message(
            embed=embeds.ok(f"🔁 Тикет передан {user.mention} (передал: {interaction.user.mention}).")
        )

    @ticket.command(name="priority", description="Сменить приоритет тикета")
    @app_commands.describe(level="Насколько срочно")
    @app_commands.choices(level=PRIORITY_CHOICES)
    async def priority(self, interaction: discord.Interaction, level: app_commands.Choice[str]):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        await self.bot.db.execute("UPDATE tickets SET priority=? WHERE id=?", (level.value, row["id"]))
        row = await self.reload_row(row["id"])
        info = await self.type_info(row["guild_id"], row["type"])
        slug = info.get("slug") or slugify(info["label"])
        await self.refresh_panel(interaction.channel, row)
        try:
            await interaction.channel.edit(
                name=channel_name_for(slug, row["id"], level.value),
                reason=f"Приоритет: {level.value}",
            )
        except discord.HTTPException:
            pass  # у Discord жёсткий лимит на переименование каналов
        await interaction.response.send_message(
            embed=embeds.ok(f"Приоритет тикета: **{level.name}**.")
        )

    @ticket.command(name="lock", description="Запретить автору писать в тикете")
    async def lock(self, interaction: discord.Interaction):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        await self.set_lock(interaction.channel, row, True)
        row = await self.reload_row(row["id"])
        await self.refresh_panel(interaction.channel, row)
        await interaction.response.send_message(
            embed=embeds.warn("🔇 Тикет заблокирован — автор пока не может писать.")
        )

    @ticket.command(name="unlock", description="Вернуть автору возможность писать")
    async def unlock(self, interaction: discord.Interaction):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        await self.set_lock(interaction.channel, row, False)
        row = await self.reload_row(row["id"])
        await self.refresh_panel(interaction.channel, row)
        await interaction.response.send_message(
            embed=embeds.ok("🔊 Тикет разблокирован — автор снова может писать.")
        )

    @ticket.command(name="note", description="Внутренняя заметка по тикету (автор её не увидит)")
    @app_commands.describe(text="Текст заметки")
    async def note(self, interaction: discord.Interaction, text: app_commands.Range[str, 1, 1000]):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        await self.bot.db.insert(
            "INSERT INTO ticket_notes(ticket_id, author_id, text, created_at) VALUES(?,?,?,?)",
            (row["id"], interaction.user.id, text, int(now_ts())),
        )
        entry = embeds.make(f"🗒️ Заметка по тикету #{row['id']:04d}", color=config.COLOR_WARN)
        entry.add_field(name="Автор заметки", value=interaction.user.mention, inline=True)
        entry.add_field(name="Канал", value=interaction.channel.mention, inline=True)
        entry.add_field(name="Текст", value=text[:1000], inline=False)
        await self.bot.send_log(interaction.guild, entry, key="ticket_log")
        await interaction.response.send_message(
            embed=embeds.ok("Заметка сохранена — она попадёт в транскрипт."), ephemeral=True
        )

    @ticket.command(name="notes", description="Показать заметки по этому тикету")
    async def notes(self, interaction: discord.Interaction):
        row = await self._staff_ticket(interaction)
        if row is None:
            return
        rows = await self.bot.db.fetchall(
            "SELECT * FROM ticket_notes WHERE ticket_id=? ORDER BY id", (row["id"],)
        )
        if not rows:
            await interaction.response.send_message(
                embed=embeds.info("Заметок пока нет.", "🗒️ Заметки"), ephemeral=True
            )
            return
        lines = [f"**<@{r['author_id']}>** · <t:{r['created_at']}:f>\n└ {r['text']}" for r in rows]
        await interaction.response.send_message(
            embed=embeds.info("\n\n".join(lines)[:4000], f"🗒️ Заметки по тикету #{row['id']:04d}"),
            ephemeral=True,
        )

    @ticket.command(name="close", description="Закрыть этот тикет")
    @app_commands.describe(reason="Причина закрытия (попадёт в лог и в ЛС автору)")
    async def close(self, interaction: discord.Interaction,
                    reason: app_commands.Range[str, 1, 500] | None = None):
        row = await self.get_ticket(interaction.channel.id)
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Эту команду нужно вызывать внутри открытого тикета."), ephemeral=True
            )
            return
        if not (interaction.user.id == row["user_id"] or await self.is_staff(interaction.user)):
            await interaction.response.send_message(
                embed=embeds.err("Закрыть тикет может его автор или поддержка."), ephemeral=True
            )
            return
        await interaction.response.send_message(embed=embeds.warn("Закрываю тикет…"), ephemeral=True)
        await self.close_ticket(interaction.channel, interaction.user, reason=reason or None)

    @ticket.command(name="reopen", description="Открыть закрытый тикет заново")
    @app_commands.describe(ticket_id="Номер тикета (например 7)")
    @access("ticket_admin")
    async def reopen(self, interaction: discord.Interaction, ticket_id: int):
        guild = interaction.guild
        db = self.bot.db
        row = await db.fetchone(
            "SELECT * FROM tickets WHERE id=? AND guild_id=?", (ticket_id, guild.id)
        )
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err(f"Тикет #{ticket_id:04d} не найден."), ephemeral=True
            )
            return
        if row["status"] == "open" and guild.get_channel(row["channel_id"]):
            await interaction.response.send_message(
                embed=embeds.warn(f"Тикет уже открыт: <#{row['channel_id']}>"), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        category_id = await db.get_setting(guild.id, "ticket_category")
        category = guild.get_channel(int(category_id)) if category_id else None
        if not isinstance(category, discord.CategoryChannel):
            await interaction.followup.send(
                embed=embeds.err("Категория тикетов не настроена — выполни `/ticket setup`."),
                ephemeral=True,
            )
            return

        info = await self.type_info(guild.id, row["type"])
        author = guild.get_member(row["user_id"])
        support_ids = await db.get_targets(guild.id, "ticket_support")
        support_roles = [r for r in (guild.get_role(i) for i in support_ids) if r]
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            guild.me: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, manage_channels=True, manage_messages=True,
                embed_links=True, attach_files=True, read_message_history=True,
            ),
        }
        if author:
            overwrites[author] = discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True,
                attach_files=True, embed_links=True,
            )
        for role in support_roles:
            overwrites[role] = discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True,
                attach_files=True, embed_links=True, manage_messages=True,
            )

        old_channel = guild.get_channel(row["channel_id"])
        slug = info.get("slug") or slugify(info["label"])
        name = channel_name_for(slug, row["id"], priority_of(row))
        try:
            if old_channel is not None:  # канал жив (архив) — просто возвращаем его в работу
                channel = old_channel
                await channel.edit(category=category, name=name, overwrites=overwrites,
                                   reason=f"Тикет переоткрыт: {interaction.user}")
            else:
                channel = await guild.create_text_channel(
                    name=name, category=category, overwrites=overwrites,
                    topic=f"Тикет #{row['id']:04d} • переоткрыт",
                    reason=f"Тикет переоткрыт: {interaction.user}",
                )
        except discord.HTTPException:
            await interaction.followup.send(
                embed=embeds.err("Не удалось создать канал. Проверь права бота."), ephemeral=True
            )
            return

        now = int(now_ts())
        await db.execute(
            "UPDATE tickets SET status='open', channel_id=?, closed_at=NULL, closed_by=NULL, "
            "close_reason=NULL, locked=0, last_activity=? WHERE id=?",
            (channel.id, now, row["id"]),
        )
        self._open_channels.add(channel.id)
        row = await self.reload_row(row["id"])
        await channel.send(
            content=f"<@{row['user_id']}>",
            embed=ticket_embed(guild, row, info),
            view=TicketControlView(),
            allowed_mentions=discord.AllowedMentions(users=True),
        )
        await channel.send(
            embed=embeds.info(f"♻️ Тикет переоткрыт по решению {interaction.user.mention}."),
            allowed_mentions=discord.AllowedMentions.none(),
        )
        await interaction.followup.send(
            embed=embeds.ok(f"Тикет #{row['id']:04d} снова открыт: {channel.mention}"), ephemeral=True
        )

    # ---- обзор и статистика
    @ticket.command(name="list", description="Список тикетов сервера")
    @app_commands.describe(user="Только тикеты этого участника", status="Статус",
                           ticket_type="Ключ типа обращения (см. /ticket type list)")
    @app_commands.choices(status=[
        app_commands.Choice(name="Открытые", value="open"),
        app_commands.Choice(name="Закрытые", value="closed"),
        app_commands.Choice(name="Все", value="all"),
    ])
    @access("ticket_manage")
    async def list_tickets(self, interaction: discord.Interaction,
                           user: discord.Member | None = None,
                           status: app_commands.Choice[str] | None = None,
                           ticket_type: str | None = None):
        sql = "SELECT * FROM tickets WHERE guild_id=?"
        params = [interaction.guild.id]
        state = status.value if status else "open"
        if state != "all":
            sql += " AND status=?"
            params.append(state)
        if user:
            sql += " AND user_id=?"
            params.append(user.id)
        if ticket_type:
            sql += " AND type=?"
            params.append(slugify(ticket_type))
        sql += " ORDER BY id DESC"
        rows = await self.bot.db.fetchall(sql, params)

        if not rows:
            await interaction.response.send_message(
                embed=embeds.info("Ничего не найдено.", "🎫 Тикеты"), ephemeral=True
            )
            return

        types = {t["key"]: t for t in await self.bot.db.get_ticket_types(interaction.guild.id)}

        def line(row):
            info = types.get(row["type"], FALLBACK_TYPE)
            mark = "🟢" if row["status"] == "open" else "⚫"
            where = f"<#{row['channel_id']}>" if row["status"] == "open" else "архив"
            lead = f" · ведёт <@{row['claimed_by']}>" if row["claimed_by"] else ""
            return (f"{mark} **#{row['id']:04d}** {info['emoji']} {info['label']} — "
                    f"<@{row['user_id']}> · {where}{lead}")

        pages = paginate(rows, PAGE_SIZE, f"🎫 Тикеты ({len(rows)})", line)
        if len(pages) == 1:
            await interaction.response.send_message(embed=pages[0], ephemeral=True)
            return
        await interaction.response.send_message(
            embed=pages[0], view=PageView(pages, interaction.user.id), ephemeral=True
        )

    @ticket.command(name="info", description="Карточка тикета")
    @app_commands.describe(ticket_id="Номер тикета (пусто — тикет этого канала)")
    @access("ticket_manage")
    async def info(self, interaction: discord.Interaction, ticket_id: int | None = None):
        row = await self.resolve_ticket(interaction, ticket_id)
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Тикет не найден. Укажи номер или вызови команду в канале тикета."),
                ephemeral=True,
            )
            return
        type_data = await self.type_info(row["guild_id"], row["type"])
        notes = await self.bot.db.fetchone(
            "SELECT COUNT(*) AS n FROM ticket_notes WHERE ticket_id=?", (row["id"],)
        )
        embed = embeds.make(f"{type_data['emoji']} Тикет #{row['id']:04d}",
                            color=PRIORITIES[priority_of(row)][1])
        embed.add_field(name="Автор", value=f"<@{row['user_id']}>", inline=True)
        embed.add_field(name="Тип", value=type_data["label"], inline=True)
        embed.add_field(name="Приоритет", value=PRIORITIES[priority_of(row)][0], inline=True)
        embed.add_field(name="Статус", value="🟢 Открыт" if row["status"] == "open" else "⚫ Закрыт",
                        inline=True)
        embed.add_field(name="Ведёт", value=f"<@{row['claimed_by']}>" if row["claimed_by"] else "—",
                        inline=True)
        embed.add_field(name="Заметок", value=str(notes["n"] if notes else 0), inline=True)
        embed.add_field(name="Открыт", value=f"<t:{row['created_at']}:f>", inline=True)
        embed.add_field(name="Закрыт",
                        value=f"<t:{row['closed_at']}:f>" if row["closed_at"] else "—", inline=True)
        if row["first_reply_at"]:
            embed.add_field(name="Первый ответ",
                            value=fmt_duration(row["first_reply_at"] - row["created_at"]), inline=True)
        if row["closed_by"]:
            embed.add_field(name="Закрыл", value=f"<@{row['closed_by']}>", inline=True)
        if row["close_reason"]:
            embed.add_field(name="Причина закрытия", value=row["close_reason"][:1000], inline=False)
        if row["rating"]:
            value = "⭐" * row["rating"] + f" ({row['rating']}/5)"
            if row["rating_comment"]:
                value += f"\n> {row['rating_comment'][:500]}"
            embed.add_field(name="Оценка", value=value, inline=False)
        embed.add_field(name="Обращение", value=f">>> {row['reason']}"[:1000], inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @ticket.command(name="transcript", description="Получить файл переписки тикета")
    @app_commands.describe(ticket_id="Номер тикета (пусто — тикет этого канала)")
    @access("ticket_manage")
    async def transcript(self, interaction: discord.Interaction, ticket_id: int | None = None):
        row = await self.resolve_ticket(interaction, ticket_id)
        if row is None:
            await interaction.response.send_message(
                embed=embeds.err("Тикет не найден."), ephemeral=True
            )
            return
        await interaction.response.defer(ephemeral=True)
        base = f"ticket-{row['id']:04d}"
        path = config.TRANSCRIPT_DIR / f"{base}.html"
        if path.exists():
            data = path.read_bytes()
        else:
            channel = interaction.guild.get_channel(row["channel_id"])
            if channel is None:
                await interaction.followup.send(
                    embed=embeds.err("Файл транскрипта не сохранился, а канал тикета уже удалён."),
                    ephemeral=True,
                )
                return
            _, data, base = await self.build_transcript(channel, row)
        await interaction.followup.send(
            embed=embeds.ok(f"Транскрипт тикета #{row['id']:04d}."),
            file=discord.File(io.BytesIO(data), filename=f"{base}.html"),
            ephemeral=True,
        )

    @ticket.command(name="stats", description="Статистика по тикетам")
    @app_commands.describe(period_days="За сколько последних дней считать (по умолчанию 30)")
    @access("ticket_manage")
    async def stats(self, interaction: discord.Interaction,
                    period_days: app_commands.Range[int, 1, 365] = 30):
        gid = interaction.guild.id
        since = int(now_ts()) - period_days * 86400
        db = self.bot.db

        async def scalar(sql, params):
            row = await db.fetchone(sql, params)
            return row["v"] if row else None

        opened = await scalar(
            "SELECT COUNT(*) AS v FROM tickets WHERE guild_id=? AND created_at>=?", (gid, since)
        )
        closed = await scalar(
            "SELECT COUNT(*) AS v FROM tickets WHERE guild_id=? AND status='closed' AND closed_at>=?",
            (gid, since),
        )
        open_now = await scalar(
            "SELECT COUNT(*) AS v FROM tickets WHERE guild_id=? AND status='open'", (gid,)
        )
        reply_avg = await scalar(
            "SELECT AVG(first_reply_at - created_at) AS v FROM tickets "
            "WHERE guild_id=? AND created_at>=? AND first_reply_at IS NOT NULL", (gid, since)
        )
        close_avg = await scalar(
            "SELECT AVG(closed_at - created_at) AS v FROM tickets "
            "WHERE guild_id=? AND created_at>=? AND closed_at IS NOT NULL", (gid, since)
        )

        embed = embeds.make(f"📊 Статистика тикетов за {period_days} дн.")
        embed.add_field(name="Открыто", value=str(opened or 0), inline=True)
        embed.add_field(name="Закрыто", value=str(closed or 0), inline=True)
        embed.add_field(name="Открыто сейчас", value=str(open_now or 0), inline=True)
        embed.add_field(name="Среднее до первого ответа", value=fmt_duration(reply_avg), inline=True)
        embed.add_field(name="Среднее до закрытия", value=fmt_duration(close_avg), inline=True)

        top = await db.fetchall(
            "SELECT closed_by, COUNT(*) AS n, AVG(rating) AS r FROM tickets "
            "WHERE guild_id=? AND status='closed' AND closed_at>=? AND closed_by IS NOT NULL "
            "GROUP BY closed_by ORDER BY n DESC LIMIT 10",
            (gid, since),
        )
        if top:
            lines = []
            for place, row in enumerate(top, start=1):
                rating = f" · ⭐ {row['r']:.1f}" if row["r"] else ""
                lines.append(f"`{place}.` <@{row['closed_by']}> — {row['n']} закрыто{rating}")
            embed.add_field(name="🏅 Топ поддержки", value="\n".join(lines), inline=False)
        else:
            embed.add_field(name="🏅 Топ поддержки", value="Пока никто не закрывал тикеты.",
                            inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Tickets(bot))
