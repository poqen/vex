"""Роли: выдача/снятие командой с проверкой иерархии и авто-выдача при заходе."""
import discord
from discord import app_commands
from discord.ext import commands

from .. import config, embeds
from ..checks import access, is_admin

TARGET_CHOICES = [
    app_commands.Choice(name="Участники", value="member"),
    app_commands.Choice(name="Боты", value="bot"),
]


class RoleTools(commands.Cog):
    role = app_commands.Group(name="role", description="Управление ролями", guild_only=True)

    def __init__(self, bot):
        self.bot = bot

    async def check_assignable(self, interaction, member, role):
        """Текст ошибки или None, если менять эту роль можно."""
        guild = interaction.guild
        invoker = interaction.user
        if role.is_default():
            return "Роль @everyone менять нельзя."
        if role.managed:
            return "Эта роль управляется интеграцией (ботом или бустом) — вручную её не выдать."
        if role >= guild.me.top_role:
            return f"Роль {role.mention} выше моей высшей роли или равна ей. Подними роль VEX в настройках сервера."
        if is_admin(invoker):
            return None
        if role >= invoker.top_role:
            return "Эта роль не ниже твоей высшей роли — выдавать её нельзя."
        if member.id != invoker.id and member.top_role >= invoker.top_role:
            return "Нельзя менять роли участника, который не ниже тебя по иерархии."
        perms = role.permissions
        if perms.administrator or perms.manage_roles or perms.manage_guild:
            return "Роли с опасными правами может выдавать только администратор."
        allowed = await self.bot.db.get_targets(guild.id, "manageable")
        if allowed and role.id not in allowed:
            return "Эта роль не входит в список ролей, которые разрешено выдавать (`/role allowed`)."
        return None

    async def _change(self, interaction, member, role, reason, give):
        error = await self.check_assignable(interaction, member, role)
        if error:
            await interaction.response.send_message(embed=embeds.err(error), ephemeral=True)
            return
        has_role = role in member.roles
        if give and has_role:
            await interaction.response.send_message(
                embed=embeds.info(f"У {member.mention} уже есть {role.mention}."), ephemeral=True
            )
            return
        if not give and not has_role:
            await interaction.response.send_message(
                embed=embeds.info(f"У {member.mention} нет роли {role.mention}."), ephemeral=True
            )
            return

        audit = f"{interaction.user} через VEX" + (f": {reason}" if reason else "")
        try:
            if give:
                await member.add_roles(role, reason=audit)
            else:
                await member.remove_roles(role, reason=audit)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=embeds.err("У меня не хватает прав (Manage Roles) или роль выше моей."), ephemeral=True
            )
            return

        verb = "выдана" if give else "снята"
        text = f"Роль {role.mention} {verb}: {member.mention}"
        await interaction.response.send_message(
            embed=embeds.ok(text), allowed_mentions=discord.AllowedMentions.none()
        )

        log = embeds.make(f"🎭 Роль {verb}", color=config.COLOR_MAIN)
        log.add_field(name="Участник", value=member.mention, inline=True)
        log.add_field(name="Роль", value=role.mention, inline=True)
        log.add_field(name="Кто", value=interaction.user.mention, inline=True)
        if reason:
            log.add_field(name="Причина", value=reason[:500], inline=False)
        await self.bot.send_log(interaction.guild, log)

    @role.command(name="add", description="Выдать роль участнику")
    @app_commands.describe(member="Кому", role="Какую роль", reason="Причина (попадёт в журнал аудита)")
    @access("role")
    async def add(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role,
                  reason: str | None = None):
        await self._change(interaction, member, role, reason, give=True)

    @role.command(name="remove", description="Снять роль с участника")
    @app_commands.describe(member="С кого", role="Какую роль", reason="Причина (попадёт в журнал аудита)")
    @access("role")
    async def remove(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role,
                     reason: str | None = None):
        await self._change(interaction, member, role, reason, give=False)

    @role.command(name="allow", description="Разрешить модераторам выдавать эту роль")
    @app_commands.describe(role="Роль")
    @access("role_admin")
    async def allow(self, interaction: discord.Interaction, role: discord.Role):
        added = await self.bot.db.add_target(interaction.guild.id, "manageable", role.id)
        text = f"{role.mention} добавлена в список выдаваемых." if added else f"{role.mention} уже в списке."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @role.command(name="deny", description="Убрать роль из списка выдаваемых")
    @app_commands.describe(role="Роль")
    @access("role_admin")
    async def deny(self, interaction: discord.Interaction, role: discord.Role):
        removed = await self.bot.db.remove_target(interaction.guild.id, "manageable", role.id)
        text = f"{role.mention} убрана из списка." if removed else f"{role.mention} не была в списке."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @role.command(name="allowed", description="Список ролей, которые разрешено выдавать")
    @access("role_admin")
    async def allowed(self, interaction: discord.Interaction):
        ids = await self.bot.db.get_targets(interaction.guild.id, "manageable")
        if ids:
            text = "\n".join(f"• <@&{i}>" for i in ids)
        else:
            text = ("Список пуст — модераторы могут выдавать любые роли ниже своей "
                    "(кроме ролей с опасными правами).")
        await interaction.response.send_message(embed=embeds.info(text, "🎭 Выдаваемые роли"), ephemeral=True)


class AutoRole(commands.Cog):
    autorole = app_commands.Group(name="autorole", description="Авто-выдача ролей при заходе", guild_only=True)

    def __init__(self, bot):
        self.bot = bot

    async def apply(self, member):
        kind = "autorole_bot" if member.bot else "autorole_member"
        ids = await self.bot.db.get_targets(member.guild.id, kind)
        me = member.guild.me
        roles = []
        for role_id in ids:
            role = member.guild.get_role(role_id)
            if role and not role.managed and role < me.top_role and role not in member.roles:
                roles.append(role)
        if not roles:
            return
        try:
            await member.add_roles(*roles, reason="VEX: авто-выдача ролей")
        except discord.HTTPException:
            return
        log = embeds.make("🎭 Авто-роль выдана", color=config.COLOR_MAIN)
        log.add_field(name="Участник", value=member.mention, inline=True)
        log.add_field(name="Роли", value=" ".join(r.mention for r in roles), inline=True)
        await self.bot.send_log(member.guild, log)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if not member.pending:  # если включена проверка (screening) — ждём её завершения
            await self.apply(member)

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.pending and not after.pending:
            await self.apply(after)

    @autorole.command(name="add", description="Добавить роль, выдаваемую при заходе")
    @app_commands.describe(role="Роль", target="Кому выдавать")
    @app_commands.choices(target=TARGET_CHOICES)
    @access("autorole")
    async def add(self, interaction: discord.Interaction, role: discord.Role,
                  target: app_commands.Choice[str]):
        if role.managed or role.is_default() or role >= interaction.guild.me.top_role:
            await interaction.response.send_message(
                embed=embeds.err("Эту роль я выдать не смогу: она выше моей, управляется интеграцией или это @everyone."),
                ephemeral=True,
            )
            return
        kind = "autorole_bot" if target.value == "bot" else "autorole_member"
        added = await self.bot.db.add_target(interaction.guild.id, kind, role.id)
        text = (f"{role.mention} будет выдаваться при заходе ({target.name.lower()})."
                if added else f"{role.mention} уже в списке.")
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @autorole.command(name="remove", description="Убрать роль из авто-выдачи")
    @app_commands.describe(role="Роль", target="Кому выдавалась")
    @app_commands.choices(target=TARGET_CHOICES)
    @access("autorole")
    async def remove(self, interaction: discord.Interaction, role: discord.Role,
                     target: app_commands.Choice[str]):
        kind = "autorole_bot" if target.value == "bot" else "autorole_member"
        removed = await self.bot.db.remove_target(interaction.guild.id, kind, role.id)
        text = f"{role.mention} убрана из авто-выдачи." if removed else f"{role.mention} не была в списке."
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    @autorole.command(name="list", description="Какие роли выдаются при заходе")
    @access("autorole")
    async def list_roles(self, interaction: discord.Interaction):
        gid = interaction.guild.id
        members = await self.bot.db.get_targets(gid, "autorole_member")
        bots = await self.bot.db.get_targets(gid, "autorole_bot")
        embed = embeds.make("🎭 Авто-выдача ролей")
        embed.add_field(name="Участникам", value=" ".join(f"<@&{i}>" for i in members) or "—", inline=False)
        embed.add_field(name="Ботам", value=" ".join(f"<@&{i}>" for i in bots) or "—", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(RoleTools(bot))
    await bot.add_cog(AutoRole(bot))
