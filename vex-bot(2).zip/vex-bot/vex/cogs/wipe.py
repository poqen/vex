"""Вайп-реакты: событие с кнопками «Приду / Не приду / Опоздаю», /noreact и статистика явки."""
import re
from datetime import datetime
from time import time as now_ts
from zoneinfo import ZoneInfo

import discord
from discord import app_commands
from discord.ext import commands, tasks

from .. import config, embeds
from ..checks import access, member_has_access

TZ = ZoneInfo(config.TIMEZONE)
LINK_RE = re.compile(r"channels/(?:\d+|@me)/(\d+)/(\d+)")
STATUSES = {
    "accepted": ("✅", "Придут"),
    "declined": ("❌", "Не придут"),
    "late": ("🕒", "Опоздают"),
}
REMIND_BEFORE = 15 * 60  # за сколько секунд напоминать участникам


# --------------------------------------------------------------------------- утилиты
def parse_datetime(date_s, time_s):
    """'25.11.2026' или '25.11' + '19:00' -> datetime в часовом поясе бота (или None)."""
    now = datetime.now(TZ)
    try:
        parts = [int(p) for p in re.split(r"[./-]", date_s.strip())]
        hour, minute = [int(p) for p in re.split(r"[:.]", time_s.strip())]
        if len(parts) == 2:
            day, month = parts
            dt = datetime(now.year, month, day, hour, minute, tzinfo=TZ)
            if dt < now:
                dt = dt.replace(year=now.year + 1)
        elif len(parts) == 3:
            day, month, year = parts
            if year < 100:
                year += 2000
            dt = datetime(year, month, day, hour, minute, tzinfo=TZ)
        else:
            return None
    except ValueError:
        return None
    return dt


def render_list(rows, status):
    lines = []
    for row in rows:
        if row["status"] != status:
            continue
        line = f"<@{row['user_id']}>"
        if row["reason"]:
            line += f" — {discord.utils.escape_markdown(row['reason'])}"
        lines.append(line)
    text = ""
    shown = 0
    for line in lines:
        if len(text) + len(line) + 1 > 1000:
            text += f"\n…и ещё {len(lines) - shown}"
            break
        text += ("\n" if text else "") + line
        shown += 1
    return len(lines), text or "—"


def build_embed(ev, rows):
    closed = bool(ev["closed"])
    embed = embeds.make(
        title=f"{'🔒' if closed else '📝'} {ev['title']}",
        description=ev["description"] or None,
        color=config.COLOR_DARK if closed else config.COLOR_MAIN,
        footer=False,
    )
    ts = int(ev["ts"])
    embed.add_field(
        name="📅 Дата и время",
        value=f"<t:{ts}:F>\n<t:{ts}:R>\n*(указано по {config.TIMEZONE})*",
        inline=False,
    )
    embed.add_field(name="🗺️ Сервер", value=ev["server"] or "—", inline=False)
    for status, (emoji, label) in STATUSES.items():
        count, text = render_list(rows, status)
        embed.add_field(name=f"{emoji} {label} ({count})", value=text, inline=True)
    note = " • приём ответов закрыт" if closed else ""
    embed.set_footer(text=f"Создал: {ev['creator_name']} • {config.BRAND}{note}")
    return embed


def chunk_mentions(members, limit=1800):
    chunks, current = [], ""
    for member in members:
        piece = member.mention + " "
        if len(current) + len(piece) > limit:
            chunks.append(current.strip())
            current = ""
        current += piece
    if current.strip():
        chunks.append(current.strip())
    return chunks


# --------------------------------------------------------------------------- интерфейс
class ReasonModal(discord.ui.Modal):
    def __init__(self, cog, ev, status, message):
        super().__init__(title="Укажи причину" if status == "declined" else "Во сколько будешь?")
        self.cog = cog
        self.ev_id = ev["message_id"]
        self.status = status
        self.message = message
        self.reason = discord.ui.TextInput(
            label="Причина" if status == "declined" else "Комментарий",
            placeholder="Например: работа / нет интернета / буду к 20:00",
            required=False,
            max_length=100,
        )
        self.add_item(self.reason)

    async def on_submit(self, interaction):
        await self.cog.save_response(self.ev_id, interaction.user.id, self.status, str(self.reason).strip())
        await interaction.response.defer()
        await self.cog.refresh_message(self.message, self.ev_id)


class EditModal(discord.ui.Modal):
    def __init__(self, cog, ev, message):
        super().__init__(title="Редактировать событие")
        self.cog = cog
        self.ev_id = ev["message_id"]
        self.message = message
        dt = datetime.fromtimestamp(ev["ts"], TZ)
        self.title_in = discord.ui.TextInput(label="Название", default=ev["title"], max_length=100)
        self.desc_in = discord.ui.TextInput(
            label="Описание", default=ev["description"] or "", style=discord.TextStyle.paragraph,
            required=False, max_length=1000,
        )
        self.date_in = discord.ui.TextInput(label="Дата (ДД.ММ.ГГГГ)", default=dt.strftime("%d.%m.%Y"),
                                            max_length=10)
        self.time_in = discord.ui.TextInput(label="Время (ЧЧ:ММ)", default=dt.strftime("%H:%M"), max_length=5)
        for item in (self.title_in, self.desc_in, self.date_in, self.time_in):
            self.add_item(item)

    async def on_submit(self, interaction):
        dt = parse_datetime(str(self.date_in), str(self.time_in))
        if dt is None:
            await interaction.response.send_message(
                embed=embeds.err("Не понял дату или время. Формат: `25.11.2026` и `19:00`."), ephemeral=True
            )
            return
        await self.cog.bot.db.execute(
            "UPDATE wipe_events SET title=?, description=?, ts=?, reminded=0 WHERE message_id=?",
            (str(self.title_in), str(self.desc_in), int(dt.timestamp()), self.ev_id),
        )
        await interaction.response.defer()
        await self.cog.refresh_message(self.message, self.ev_id)


class WipeView(discord.ui.View):
    def __init__(self, closed=False):
        super().__init__(timeout=None)
        if closed:
            for child in self.children:
                if getattr(child, "custom_id", None) != "vex:wipe:settings":
                    child.disabled = True

    @discord.ui.button(label="Приду", emoji="✅", style=discord.ButtonStyle.success, custom_id="vex:wipe:accepted")
    async def accept(self, interaction, button):
        await interaction.client.get_cog("Wipe").handle_response(interaction, "accepted")

    @discord.ui.button(label="Не приду", emoji="❌", style=discord.ButtonStyle.danger, custom_id="vex:wipe:declined")
    async def decline(self, interaction, button):
        await interaction.client.get_cog("Wipe").handle_response(interaction, "declined")

    @discord.ui.button(label="Опоздаю", emoji="🕒", style=discord.ButtonStyle.secondary, custom_id="vex:wipe:late")
    async def late(self, interaction, button):
        await interaction.client.get_cog("Wipe").handle_response(interaction, "late")

    @discord.ui.button(emoji="📝", style=discord.ButtonStyle.secondary, custom_id="vex:wipe:edit")
    async def edit(self, interaction, button):
        await interaction.client.get_cog("Wipe").handle_edit(interaction)

    @discord.ui.button(emoji="⚙️", style=discord.ButtonStyle.primary, custom_id="vex:wipe:settings")
    async def settings(self, interaction, button):
        await interaction.client.get_cog("Wipe").handle_settings(interaction)


class SettingsView(discord.ui.View):
    def __init__(self, cog, ev_id, message):
        super().__init__(timeout=120)
        self.cog = cog
        self.ev_id = ev_id
        self.message = message

    @discord.ui.button(label="Закрыть / открыть приём", emoji="🔒", style=discord.ButtonStyle.secondary)
    async def toggle(self, interaction, button):
        ev = await self.cog.get_event(self.ev_id)
        new_state = 0 if ev["closed"] else 1
        await self.cog.bot.db.execute("UPDATE wipe_events SET closed=? WHERE message_id=?",
                                      (new_state, self.ev_id))
        await self.cog.refresh_message(self.message, self.ev_id)
        text = "Приём ответов закрыт." if new_state else "Приём ответов снова открыт."
        await interaction.response.edit_message(embed=embeds.ok(text), view=None)

    @discord.ui.button(label="Напомнить не ответившим", emoji="🔔", style=discord.ButtonStyle.primary)
    async def remind(self, interaction, button):
        ev = await self.cog.get_event(self.ev_id)
        pending = await self.cog.pending_members(interaction.guild, self.message.channel, ev)
        if not pending:
            await interaction.response.edit_message(embed=embeds.ok("Все уже ответили."), view=None)
            return
        await interaction.response.edit_message(
            embed=embeds.ok(f"Напоминаю {len(pending)} участникам."), view=None
        )
        for chunk in chunk_mentions(pending):
            await self.message.reply(
                f"🔔 Отметьтесь, пожалуйста, под событием!\n{chunk}",
                allowed_mentions=discord.AllowedMentions(users=True),
            )

    @discord.ui.button(label="Удалить событие", emoji="🗑️", style=discord.ButtonStyle.danger)
    async def delete(self, interaction, button):
        db = self.cog.bot.db
        await db.execute("DELETE FROM wipe_responses WHERE message_id=?", (self.ev_id,))
        await db.execute("DELETE FROM wipe_events WHERE message_id=?", (self.ev_id,))
        try:
            await self.message.delete()
        except discord.HTTPException:
            pass
        await interaction.response.edit_message(embed=embeds.ok("Событие удалено."), view=None)


# --------------------------------------------------------------------------- модуль
class Wipe(commands.Cog):
    wipe = app_commands.Group(name="wipe", description="Вайп-события клана", guild_only=True)

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(WipeView())
        self.reminder_loop.start()

    async def cog_unload(self):
        self.reminder_loop.cancel()

    # ---- данные
    async def get_event(self, message_id):
        return await self.bot.db.fetchone("SELECT * FROM wipe_events WHERE message_id=?", (message_id,))

    async def get_rows(self, message_id):
        return await self.bot.db.fetchall(
            "SELECT user_id, status, reason FROM wipe_responses WHERE message_id=? ORDER BY rowid",
            (message_id,),
        )

    async def save_response(self, message_id, user_id, status, reason):
        await self.bot.db.execute(
            "INSERT INTO wipe_responses(message_id, user_id, status, reason) VALUES(?,?,?,?) "
            "ON CONFLICT(message_id, user_id) DO UPDATE SET status=excluded.status, reason=excluded.reason",
            (message_id, user_id, status, reason or None),
        )

    async def refresh_message(self, message, message_id):
        ev = await self.get_event(message_id)
        if ev is None:
            return
        rows = await self.get_rows(message_id)
        try:
            await message.edit(embed=build_embed(ev, rows), view=WipeView(closed=bool(ev["closed"])))
        except discord.HTTPException:
            pass

    async def can_manage(self, member, ev):
        return member.id == ev["creator_id"] or await member_has_access(self.bot, member, "wipe")

    async def pending_members(self, guild, channel, ev, role=None):
        rows = await self.get_rows(ev["message_id"]) if ev else []
        responded = {r["user_id"] for r in rows}
        if role is None and ev and ev["ping_role_id"]:
            role = guild.get_role(ev["ping_role_id"])
        base = role.members if role else channel.members
        return [m for m in base if not m.bot and m.id not in responded]

    # ---- кнопки
    async def handle_response(self, interaction, status):
        ev = await self.get_event(interaction.message.id)
        if ev is None:
            await interaction.response.send_message(
                embed=embeds.err("Это событие уже не отслеживается."), ephemeral=True
            )
            return
        if ev["closed"]:
            await interaction.response.send_message(
                embed=embeds.warn("Приём ответов закрыт."), ephemeral=True
            )
            return

        existing = await self.bot.db.fetchone(
            "SELECT status FROM wipe_responses WHERE message_id=? AND user_id=?",
            (ev["message_id"], interaction.user.id),
        )
        if existing and existing["status"] == status:  # повторное нажатие снимает ответ
            await self.bot.db.execute(
                "DELETE FROM wipe_responses WHERE message_id=? AND user_id=?",
                (ev["message_id"], interaction.user.id),
            )
        elif status != "accepted" and ev["ask_reason"]:
            await interaction.response.send_modal(ReasonModal(self, ev, status, interaction.message))
            return
        else:
            await self.save_response(ev["message_id"], interaction.user.id, status, None)

        rows = await self.get_rows(ev["message_id"])
        await interaction.response.edit_message(embed=build_embed(ev, rows), view=WipeView())

    async def handle_edit(self, interaction):
        ev = await self.get_event(interaction.message.id)
        if ev is None:
            await interaction.response.send_message(embed=embeds.err("Событие не найдено."), ephemeral=True)
            return
        if not await self.can_manage(interaction.user, ev):
            await interaction.response.send_message(
                embed=embeds.err("Редактировать может автор события или модерация."), ephemeral=True
            )
            return
        await interaction.response.send_modal(EditModal(self, ev, interaction.message))

    async def handle_settings(self, interaction):
        ev = await self.get_event(interaction.message.id)
        if ev is None:
            await interaction.response.send_message(embed=embeds.err("Событие не найдено."), ephemeral=True)
            return
        if not await self.can_manage(interaction.user, ev):
            await interaction.response.send_message(
                embed=embeds.err("Настройки доступны автору события и модерации."), ephemeral=True
            )
            return
        await interaction.response.send_message(
            embed=embeds.info("Что сделать с событием?", "⚙️ Настройки события"),
            view=SettingsView(self, ev["message_id"], interaction.message),
            ephemeral=True,
        )

    # ---- напоминание за 15 минут
    @tasks.loop(minutes=1)
    async def reminder_loop(self):
        try:
            now = int(now_ts())
            events = await self.bot.db.fetchall(
                "SELECT * FROM wipe_events WHERE closed=0 AND reminded=0 AND ts > ? AND ts <= ?",
                (now, now + REMIND_BEFORE),
            )
            for ev in events:
                await self.bot.db.execute(
                    "UPDATE wipe_events SET reminded=1 WHERE message_id=?", (ev["message_id"],)
                )
                channel = self.bot.get_channel(ev["channel_id"])
                if channel is None:
                    continue
                rows = await self.get_rows(ev["message_id"])
                ids = [r["user_id"] for r in rows if r["status"] in ("accepted", "late")]
                if not ids:
                    continue
                embed = embeds.make(
                    f"⏰ Скоро начало: {ev['title']}",
                    f"Старт <t:{ev['ts']}:R>. Все, кто отметился, — на связь!",
                )
                mentions = " ".join(f"<@{i}>" for i in ids)[:1900]
                await channel.send(
                    content=mentions, embed=embed, allowed_mentions=discord.AllowedMentions(users=True)
                )
        except Exception:  # цикл не должен умирать из-за одной ошибки
            import logging

            logging.getLogger("vex").exception("Ошибка в цикле напоминаний")

    @reminder_loop.before_loop
    async def before_reminder_loop(self):
        await self.bot.wait_until_ready()

    # ---- команды
    @app_commands.command(name="wipereact", description="Создать событие с реакциями (вайп, рейд, сбор)")
    @app_commands.describe(
        title="Название события",
        description="Описание (\\n — перенос строки)",
        date="Дата: ДД.ММ.ГГГГ или ДД.ММ",
        time="Время: ЧЧ:ММ",
        ask_for_reason="Спрашивать причину при «Не приду» и «Опоздаю»",
        server="Сервер Rust / IP (необязательно)",
        ping_role="Роль, которую упомянуть в сообщении (необязательно)",
    )
    @app_commands.guild_only()
    @access("wipe")
    async def wipereact(self, interaction: discord.Interaction,
                        title: app_commands.Range[str, 1, 100],
                        description: str,
                        date: str, time: str,
                        ask_for_reason: bool = False,
                        server: str | None = None,
                        ping_role: discord.Role | None = None):
        dt = parse_datetime(date, time)
        if dt is None:
            await interaction.response.send_message(
                embed=embeds.err("Не понял дату или время. Пример: дата `25.11.2026`, время `19:00`."),
                ephemeral=True,
            )
            return
        if dt < datetime.now(TZ):
            await interaction.response.send_message(
                embed=embeds.err("Эта дата уже в прошлом."), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        ev = {
            "title": title,
            "description": description.replace("\\n", "\n")[:1000],
            "server": server[:200] if server else None,
            "ts": int(dt.timestamp()),
            "closed": 0,
            "creator_name": interaction.user.display_name,
        }
        try:
            message = await interaction.channel.send(
                content=ping_role.mention if ping_role else None,
                embed=build_embed(ev, []),
                view=WipeView(),
                allowed_mentions=discord.AllowedMentions(roles=True),
            )
        except discord.Forbidden:
            await interaction.followup.send(
                embed=embeds.err("У меня нет прав писать в этот канал."), ephemeral=True
            )
            return

        await self.bot.db.execute(
            "INSERT INTO wipe_events(message_id, guild_id, channel_id, creator_id, creator_name, title, "
            "description, server, ts, ask_reason, ping_role_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (message.id, interaction.guild.id, message.channel.id, interaction.user.id,
             ev["creator_name"], ev["title"], ev["description"], ev["server"], ev["ts"],
             int(ask_for_reason), ping_role.id if ping_role else None),
        )
        await interaction.followup.send(embed=embeds.ok("Событие создано."), ephemeral=True)

    @app_commands.command(name="noreact", description="Показать, кто не отреагировал на сообщение")
    @app_commands.describe(
        message="Ссылка на сообщение или его ID",
        role="Проверять только участников этой роли (по умолчанию — все, кто видит канал)",
        ping="Сразу упомянуть всех не ответивших",
    )
    @app_commands.guild_only()
    @access("wipe")
    async def noreact(self, interaction: discord.Interaction, message: str,
                      role: discord.Role | None = None, ping: bool = False):
        guild = interaction.guild
        match = LINK_RE.search(message)
        if match:
            channel_id, message_id = int(match.group(1)), int(match.group(2))
        elif message.strip().isdigit():
            channel_id, message_id = None, int(message.strip())
        else:
            await interaction.response.send_message(
                embed=embeds.err("Пришли ссылку на сообщение или его ID."), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=not ping)

        ev = await self.get_event(message_id)
        if channel_id is None:
            channel_id = ev["channel_id"] if ev else interaction.channel.id
        channel = guild.get_channel_or_thread(channel_id)
        if channel is None:
            await interaction.followup.send(embed=embeds.err("Не нашёл такой канал."), ephemeral=True)
            return
        try:
            target = await channel.fetch_message(message_id)
        except (discord.NotFound, discord.Forbidden):
            await interaction.followup.send(
                embed=embeds.err("Не нашёл сообщение. Если оно в другом канале — пришли ссылку."),
                ephemeral=True,
            )
            return

        if ev:
            missing = await self.pending_members(guild, channel, ev, role)
        else:
            responded = set()
            for reaction in target.reactions:
                async for user in reaction.users():
                    responded.add(user.id)
            base = role.members if role else channel.members
            missing = [m for m in base if not m.bot and m.id not in responded]

        if not missing:
            await interaction.followup.send(embed=embeds.ok("Все уже отреагировали 🎉"))
            return

        if ping:
            chunks = chunk_mentions(missing)
            await interaction.followup.send(
                content=f"🔔 Не отреагировали ({len(missing)}) — отметьтесь здесь: {target.jump_url}\n{chunks[0]}",
                allowed_mentions=discord.AllowedMentions(users=True),
            )
            for chunk in chunks[1:]:
                await interaction.followup.send(
                    content=chunk, allowed_mentions=discord.AllowedMentions(users=True)
                )
            return

        listing = ""
        shown = 0
        for member in missing:
            piece = member.mention + "\n"
            if len(listing) + len(piece) > 3800:
                listing += f"…и ещё {len(missing) - shown}"
                break
            listing += piece
            shown += 1
        embed = embeds.make(f"🔍 Не отреагировали ({len(missing)})", listing)
        embed.add_field(name="Сообщение", value=f"[Перейти]({target.jump_url})", inline=False)
        await interaction.followup.send(embed=embed)

    @wipe.command(name="stats", description="Кто чаще всех ходит на вайпы")
    @app_commands.describe(days="За сколько последних дней считать (по умолчанию 30)")
    @access("wipe")
    async def wipe_stats(self, interaction: discord.Interaction,
                         days: app_commands.Range[int, 1, 365] = 30):
        gid = interaction.guild.id
        since = int(now_ts()) - days * 86400
        db = self.bot.db

        total_row = await db.fetchone(
            "SELECT COUNT(*) AS n FROM wipe_events WHERE guild_id=? AND ts>=?", (gid, since)
        )
        events = total_row["n"] if total_row else 0
        if not events:
            await interaction.response.send_message(
                embed=embeds.info(f"За последние {days} дн. событий не было.", "📊 Явка на вайпы"),
                ephemeral=True,
            )
            return

        rows = await db.fetchall(
            "SELECT r.user_id AS user_id, "
            "SUM(CASE WHEN r.status='accepted' THEN 1 ELSE 0 END) AS came, "
            "SUM(CASE WHEN r.status='late' THEN 1 ELSE 0 END) AS late, "
            "SUM(CASE WHEN r.status='declined' THEN 1 ELSE 0 END) AS skipped "
            "FROM wipe_responses r JOIN wipe_events e ON e.message_id = r.message_id "
            "WHERE e.guild_id=? AND e.ts>=? "
            "GROUP BY r.user_id ORDER BY came DESC, late DESC LIMIT 15",
            (gid, since),
        )

        embed = embeds.make(f"📊 Явка на вайпы за {days} дн.")
        embed.add_field(name="Событий", value=str(events), inline=True)
        embed.add_field(name="Отметившихся", value=str(len(rows)), inline=True)
        if rows:
            lines = []
            for place, row in enumerate(rows, start=1):
                percent = row["came"] * 100 // events
                lines.append(
                    f"`{place:>2}.` <@{row['user_id']}> — ✅ {row['came']} · 🕒 {row['late']} · "
                    f"❌ {row['skipped']} · явка **{percent}%**"
                )
            embed.add_field(name="🏅 Топ участников", value="\n".join(lines)[:1024], inline=False)
        else:
            embed.add_field(name="🏅 Топ участников", value="Никто ещё не отметился.", inline=False)
        embed.set_footer(text=f"{config.FOOTER} • явка = «приду» от общего числа событий")
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Wipe(bot))
