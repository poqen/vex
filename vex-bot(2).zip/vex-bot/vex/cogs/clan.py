"""Клан: состав (/roster), карточки участников (/nick) и голосования (/poll)."""
import json
import logging
from time import time as now_ts

import discord
from discord import app_commands
from discord.ext import commands

from .. import config, embeds
from ..checks import access, member_has_access
from .tickets import PageView, paginate

log = logging.getLogger("vex")

NUMBERS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
MAX_OPTIONS = 10
BAR_WIDTH = 12
ROSTER_PAGE = 15


# --------------------------------------------------------------------------- утилиты
def bar(part, total, width=BAR_WIDTH):
    """5 из 12 -> '█████░░░░░░░'."""
    filled = round(width * part / total) if total else 0
    filled = max(0, min(width, filled))
    return "█" * filled + "░" * (width - filled)


def poll_embed(poll, options, counts, voters):
    total = sum(counts)
    closed = bool(poll["closed"])
    embed = embeds.make(
        f"{'🔒' if closed else '📊'} {poll['question']}",
        color=config.COLOR_DARK if closed else config.COLOR_MAIN,
    )
    lines = []
    for index, option in enumerate(options):
        count = counts[index]
        percent = (count * 100 // total) if total else 0
        lines.append(f"{NUMBERS[index]} **{option}**\n`{bar(count, total)}` {percent}% · {count}")
    embed.description = "\n".join(lines)[:4000]

    mode = ["несколько вариантов" if poll["multi"] else "один вариант",
            "анонимно" if poll["anonymous"] else "открыто"]
    embed.add_field(name="Голосов", value=str(total), inline=True)
    embed.add_field(name="Участников", value=str(voters), inline=True)
    embed.add_field(name="Режим", value=" · ".join(mode), inline=True)
    note = " • голосование закрыто" if closed else ""
    embed.set_footer(text=f"{config.FOOTER}{note}")
    return embed


class PollButton(discord.ui.Button):
    def __init__(self, index, label):
        super().__init__(
            label=label[:80] or f"Вариант {index + 1}",
            emoji=NUMBERS[index],
            style=discord.ButtonStyle.secondary,
            custom_id=f"vex:poll:{index}",
            row=index // 5,
        )
        self.index = index

    async def callback(self, interaction):
        cog = interaction.client.get_cog("Clan")
        if cog is None:
            return
        await cog.handle_vote(interaction, self.index)


class PollView(discord.ui.View):
    """Постоянная вьюха: custom_id vex:poll:<номер>, сам опрос ищется по id сообщения."""

    def __init__(self, labels=None, closed=False):
        super().__init__(timeout=None)
        labels = labels if labels is not None else [f"Вариант {i + 1}" for i in range(MAX_OPTIONS)]
        for index, label in enumerate(labels[:MAX_OPTIONS]):
            button = PollButton(index, label)
            button.disabled = closed
            self.add_item(button)


# --------------------------------------------------------------------------- модуль
class Clan(commands.Cog):
    nick = app_commands.Group(name="nick", description="Карточка участника клана", guild_only=True)
    poll = app_commands.Group(name="poll", description="Голосования", guild_only=True)

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(PollView())

    # ---- состав клана
    @app_commands.command(name="roster", description="Состав клана")
    @app_commands.describe(role="Показать только участников с этой ролью")
    @app_commands.guild_only()
    @access("roster")
    async def roster(self, interaction: discord.Interaction, role: discord.Role | None = None):
        guild = interaction.guild
        cards = {r["user_id"]: r for r in await self.bot.db.list_clan_members(guild.id)}

        def hours_of(member):
            card = cards.get(member.id)
            return (card["hours"] or 0) if card else 0

        if role is not None:
            members = sorted([m for m in role.members if not m.bot], key=hours_of, reverse=True)
            title = f"⚔️ Состав: {role.name}"
        else:
            members = sorted(
                [m for m in (guild.get_member(uid) for uid in cards) if m is not None],
                key=hours_of, reverse=True,
            )
            title = "⚔️ Состав клана"

        if not members:
            await interaction.response.send_message(
                embed=embeds.info(
                    "Пока никто не заполнил карточку. Команда `/nick set` — и ты в списке.", title
                ),
                ephemeral=True,
            )
            return

        def line(member):
            card = cards.get(member.id)
            nick = card["nick"] if card and card["nick"] else member.display_name
            hours = f"{card['hours']} ч" if card and card["hours"] else "— ч"
            timezone = card["timezone"] if card and card["timezone"] else "—"
            return f"• **{nick}** — {member.mention} — {hours} — {timezone}"

        pages = paginate(members, ROSTER_PAGE, f"{title} ({len(members)})", line)
        if len(pages) == 1:
            await interaction.response.send_message(embed=pages[0])
            return
        await interaction.response.send_message(
            embed=pages[0], view=PageView(pages, interaction.user.id)
        )

    # ---- карточка участника
    @nick.command(name="set", description="Заполнить свою карточку участника")
    @app_commands.describe(nick="Ник в игре", hours="Часов в Rust",
                           timezone="Часовой пояс, например МСК+2")
    async def nick_set(self, interaction: discord.Interaction,
                       nick: app_commands.Range[str, 1, 64],
                       hours: app_commands.Range[int, 0, 100000] | None = None,
                       timezone: app_commands.Range[str, 1, 32] | None = None):
        await self.bot.db.set_clan_member(
            interaction.guild.id, interaction.user.id, nick=nick, hours=hours, timezone=timezone
        )
        lines = [f"Ник в игре: **{nick}**"]
        if hours is not None:
            lines.append(f"Часов: **{hours}**")
        if timezone:
            lines.append(f"Часовой пояс: **{timezone}**")
        await interaction.response.send_message(
            embed=embeds.ok("\n".join(lines), "Карточка сохранена"), ephemeral=True
        )

    @nick.command(name="show", description="Показать карточку участника")
    @app_commands.describe(user="Чья карточка (по умолчанию — твоя)")
    async def nick_show(self, interaction: discord.Interaction, user: discord.Member | None = None):
        member = user or interaction.user
        card = await self.bot.db.get_clan_member(interaction.guild.id, member.id)
        tickets = await self.bot.db.fetchone(
            "SELECT COUNT(*) AS n FROM tickets WHERE guild_id=? AND user_id=?",
            (interaction.guild.id, member.id),
        )
        embed = embeds.make(f"🎖️ {member.display_name}")
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Ник в игре",
                        value=(card["nick"] if card and card["nick"] else "—"), inline=True)
        embed.add_field(name="Часов в Rust",
                        value=(str(card["hours"]) if card and card["hours"] else "—"), inline=True)
        embed.add_field(name="Часовой пояс",
                        value=(card["timezone"] if card and card["timezone"] else "—"), inline=True)
        embed.add_field(name="Discord", value=f"{member.mention}\n`{member}`", inline=True)
        if member.joined_at:
            embed.add_field(name="В клане с",
                            value=discord.utils.format_dt(member.joined_at, "D"), inline=True)
        embed.add_field(name="Тикетов", value=str(tickets["n"] if tickets else 0), inline=True)
        roles = [r.mention for r in reversed(member.roles) if not r.is_default()]
        embed.add_field(name="Роли", value=" ".join(roles)[:1000] or "—", inline=False)
        if card and card["updated_at"]:
            embed.description = f"Карточка обновлена <t:{card['updated_at']}:R>"
        await interaction.response.send_message(embed=embed)

    @nick.command(name="clear", description="Очистить карточку")
    @app_commands.describe(user="Чью карточку очистить (чужую — только поддержке)")
    async def nick_clear(self, interaction: discord.Interaction, user: discord.Member | None = None):
        target = user or interaction.user
        if target.id != interaction.user.id and not await member_has_access(
            self.bot, interaction.user, "roster"
        ):
            await interaction.response.send_message(
                embed=embeds.err("Чужую карточку может очистить только поддержка."), ephemeral=True
            )
            return
        removed = await self.bot.db.clear_clan_member(interaction.guild.id, target.id)
        text = (f"Карточка {target.mention} очищена."
                if removed else f"У {target.mention} и не было карточки.")
        await interaction.response.send_message(embed=embeds.ok(text), ephemeral=True)

    # ---- голосования
    async def get_poll(self, message_id):
        return await self.bot.db.fetchone("SELECT * FROM polls WHERE message_id=?", (message_id,))

    async def poll_state(self, poll):
        """Возвращает (варианты, счётчики, число проголосовавших)."""
        try:
            options = json.loads(poll["options"])
        except (ValueError, TypeError):
            options = []
        counts = [0] * len(options)
        rows = await self.bot.db.fetchall(
            "SELECT user_id, option_index FROM poll_votes WHERE message_id=?", (poll["message_id"],)
        )
        voters = set()
        for row in rows:
            voters.add(row["user_id"])
            if 0 <= row["option_index"] < len(counts):
                counts[row["option_index"]] += 1
        return options, counts, len(voters)

    async def handle_vote(self, interaction, index):
        poll = await self.get_poll(interaction.message.id)
        if poll is None:
            await interaction.response.send_message(
                embed=embeds.err("Это голосование больше не отслеживается."), ephemeral=True
            )
            return
        if poll["closed"]:
            await interaction.response.send_message(
                embed=embeds.warn("Голосование закрыто."), ephemeral=True
            )
            return
        options, _, _ = await self.poll_state(poll)
        if index >= len(options):
            await interaction.response.send_message(
                embed=embeds.err("Такого варианта нет."), ephemeral=True
            )
            return

        db = self.bot.db
        existing = await db.fetchone(
            "SELECT 1 FROM poll_votes WHERE message_id=? AND user_id=? AND option_index=?",
            (poll["message_id"], interaction.user.id, index),
        )
        if existing:  # повторное нажатие снимает голос
            await db.execute(
                "DELETE FROM poll_votes WHERE message_id=? AND user_id=? AND option_index=?",
                (poll["message_id"], interaction.user.id, index),
            )
        else:
            if not poll["multi"]:
                await db.execute(
                    "DELETE FROM poll_votes WHERE message_id=? AND user_id=?",
                    (poll["message_id"], interaction.user.id),
                )
            await db.execute(
                "INSERT OR IGNORE INTO poll_votes(message_id, user_id, option_index) VALUES(?,?,?)",
                (poll["message_id"], interaction.user.id, index),
            )

        options, counts, voters = await self.poll_state(poll)
        await interaction.response.edit_message(
            embed=poll_embed(poll, options, counts, voters), view=PollView(options)
        )

    @poll.command(name="create", description="Создать голосование с кнопками")
    @app_commands.describe(
        question="Вопрос",
        options="Варианты через | — например: Да | Нет | Воздержусь",
        multi="Разрешить выбирать несколько вариантов",
        anonymous="Скрывать, кто за что проголосовал",
        ping_role="Упомянуть роль",
    )
    @access("poll")
    async def poll_create(self, interaction: discord.Interaction,
                          question: app_commands.Range[str, 1, 240],
                          options: str,
                          multi: bool = False,
                          anonymous: bool = True,
                          ping_role: discord.Role | None = None):
        parsed = [o.strip()[:80] for o in options.split("|") if o.strip()]
        if len(parsed) < 2:
            await interaction.response.send_message(
                embed=embeds.err("Нужно минимум два варианта, разделённых `|`."), ephemeral=True
            )
            return
        if len(parsed) > MAX_OPTIONS:
            await interaction.response.send_message(
                embed=embeds.err(f"Максимум {MAX_OPTIONS} вариантов."), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        draft = {"question": question, "multi": int(multi), "anonymous": int(anonymous), "closed": 0}
        try:
            message = await interaction.channel.send(
                content=ping_role.mention if ping_role else None,
                embed=poll_embed(draft, parsed, [0] * len(parsed), 0),
                view=PollView(parsed),
                allowed_mentions=discord.AllowedMentions(roles=True),
            )
        except discord.Forbidden:
            await interaction.followup.send(
                embed=embeds.err("У меня нет прав писать в этот канал."), ephemeral=True
            )
            return

        await self.bot.db.execute(
            "INSERT INTO polls(message_id, guild_id, channel_id, author_id, question, options, "
            "multi, anonymous, closed, created_at) VALUES(?,?,?,?,?,?,?,?,0,?)",
            (message.id, interaction.guild.id, interaction.channel.id, interaction.user.id,
             question, json.dumps(parsed, ensure_ascii=False), int(multi), int(anonymous),
             int(now_ts())),
        )
        await interaction.followup.send(
            embed=embeds.ok(f"Голосование создано: [перейти]({message.jump_url})"), ephemeral=True
        )

    async def fetch_poll_message(self, interaction, message_id):
        """Находит опрос и его сообщение. Возвращает (poll, message) или (None, None)."""
        raw = str(message_id).strip()
        if not raw.isdigit():
            await interaction.response.send_message(
                embed=embeds.err("`message_id` — это числовой ID сообщения с голосованием."),
                ephemeral=True,
            )
            return None, None
        poll = await self.get_poll(int(raw))
        if poll is None or poll["guild_id"] != interaction.guild.id:
            await interaction.response.send_message(
                embed=embeds.err("Голосование не найдено."), ephemeral=True
            )
            return None, None
        channel = interaction.guild.get_channel(poll["channel_id"])
        message = None
        if channel is not None:
            try:
                message = await channel.fetch_message(poll["message_id"])
            except (discord.NotFound, discord.Forbidden):
                message = None
        return poll, message

    @poll.command(name="close", description="Закрыть голосование и показать итог")
    @app_commands.describe(message_id="ID сообщения с голосованием")
    @access("poll")
    async def poll_close(self, interaction: discord.Interaction, message_id: str):
        poll, message = await self.fetch_poll_message(interaction, message_id)
        if poll is None:
            return
        await self.bot.db.execute(
            "UPDATE polls SET closed=1 WHERE message_id=?", (poll["message_id"],)
        )
        poll = await self.get_poll(poll["message_id"])
        options, counts, voters = await self.poll_state(poll)
        if message is not None:
            try:
                await message.edit(embed=poll_embed(poll, options, counts, voters),
                                   view=PollView(options, closed=True))
            except discord.HTTPException:
                pass
        await interaction.response.send_message(
            embed=embeds.ok("Голосование закрыто. Итог обновлён в сообщении."), ephemeral=True
        )

    @poll.command(name="results", description="Кто за что проголосовал")
    @app_commands.describe(message_id="ID сообщения с голосованием")
    @access("poll")
    async def poll_results(self, interaction: discord.Interaction, message_id: str):
        poll, _ = await self.fetch_poll_message(interaction, message_id)
        if poll is None:
            return
        options, counts, voters = await self.poll_state(poll)
        embed = poll_embed(poll, options, counts, voters)
        embed.title = f"📋 Итоги: {poll['question']}"[:256]

        if poll["anonymous"]:
            embed.add_field(name="Голосовавшие",
                            value="Голосование анонимное — списка нет.", inline=False)
        else:
            rows = await self.bot.db.fetchall(
                "SELECT user_id, option_index FROM poll_votes WHERE message_id=? "
                "ORDER BY option_index", (poll["message_id"],)
            )
            by_option = {}
            for row in rows:
                by_option.setdefault(row["option_index"], []).append(row["user_id"])
            for index, option in enumerate(options):
                ids = by_option.get(index, [])
                value = " ".join(f"<@{i}>" for i in ids)[:1000] or "—"
                embed.add_field(name=f"{NUMBERS[index]} {option} ({len(ids)})", value=value,
                                inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Clan(bot))
