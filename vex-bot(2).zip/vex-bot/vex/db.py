"""Небольшая обёртка над SQLite (стандартная библиотека, без доп. зависимостей)."""
import asyncio
import json
import sqlite3
import threading
from pathlib import Path
from time import time as now_ts

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    guild_id INTEGER NOT NULL,
    key      TEXT    NOT NULL,
    value    TEXT    NOT NULL,
    PRIMARY KEY (guild_id, key)
);

-- Универсальное хранилище «ролей и каналов по назначению»:
--   cmd:<ключ>            роли с доступом к команде
--   ticket_support        роли поддержки тикетов
--   manageable            роли, которые модераторы могут выдавать
--   autorole_member       роли для новых участников
--   autorole_bot          роли для новых ботов
--   automod_bypass        роли, которых не трогает автомодерация
--   automod_ignore_channel каналы, где автомодерация выключена
CREATE TABLE IF NOT EXISTS guild_targets (
    guild_id  INTEGER NOT NULL,
    kind      TEXT    NOT NULL,
    target_id INTEGER NOT NULL,
    PRIMARY KEY (guild_id, kind, target_id)
);

CREATE TABLE IF NOT EXISTS allowed_domains (
    guild_id INTEGER NOT NULL,
    domain   TEXT    NOT NULL,
    PRIMARY KEY (guild_id, domain)
);

CREATE TABLE IF NOT EXISTS tickets (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id       INTEGER NOT NULL,
    channel_id     INTEGER NOT NULL DEFAULT 0,
    user_id        INTEGER NOT NULL,
    type           TEXT    NOT NULL,
    reason         TEXT    NOT NULL DEFAULT '',
    claimed_by     INTEGER,
    status         TEXT    NOT NULL DEFAULT 'open',
    created_at     INTEGER NOT NULL,
    closed_at      INTEGER,
    priority       TEXT    NOT NULL DEFAULT 'normal',
    close_reason   TEXT,
    closed_by      INTEGER,
    rating         INTEGER,
    rating_comment TEXT,
    last_activity  INTEGER,
    first_reply_at INTEGER,
    locked         INTEGER NOT NULL DEFAULT 0,
    transcript     TEXT
);

-- Внутренние заметки поддержки: автор тикета их не видит.
CREATE TABLE IF NOT EXISTS ticket_notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id  INTEGER NOT NULL,
    author_id  INTEGER NOT NULL,
    text       TEXT    NOT NULL,
    created_at INTEGER NOT NULL
);

-- Кому запрещено открывать тикеты.
CREATE TABLE IF NOT EXISTS ticket_blacklist (
    guild_id INTEGER,
    user_id  INTEGER,
    reason   TEXT,
    added_by INTEGER,
    added_at INTEGER,
    PRIMARY KEY (guild_id, user_id)
);

-- Свои типы обращений сервера. Пусто = берутся значения из config.TICKET_TYPES.
CREATE TABLE IF NOT EXISTS ticket_types (
    guild_id    INTEGER,
    key         TEXT,
    label       TEXT    NOT NULL,
    emoji       TEXT    NOT NULL DEFAULT '🎫',
    description TEXT    NOT NULL DEFAULT '',
    slug        TEXT    NOT NULL,
    position    INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, key)
);

-- Сохранённые заготовки эмбедов для /say.
CREATE TABLE IF NOT EXISTS embed_templates (
    guild_id   INTEGER,
    name       TEXT,
    payload    TEXT    NOT NULL,
    author_id  INTEGER,
    created_at INTEGER,
    PRIMARY KEY (guild_id, name)
);

-- Карточки участников клана (/nick, /roster).
CREATE TABLE IF NOT EXISTS clan_members (
    guild_id   INTEGER,
    user_id    INTEGER,
    nick       TEXT,
    hours      INTEGER,
    timezone   TEXT,
    note       TEXT,
    updated_at INTEGER,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS polls (
    message_id INTEGER PRIMARY KEY,
    guild_id   INTEGER NOT NULL,
    channel_id INTEGER NOT NULL,
    author_id  INTEGER NOT NULL,
    question   TEXT    NOT NULL,
    options    TEXT    NOT NULL,
    multi      INTEGER NOT NULL DEFAULT 0,
    anonymous  INTEGER NOT NULL DEFAULT 1,
    closed     INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS poll_votes (
    message_id   INTEGER NOT NULL,
    user_id      INTEGER NOT NULL,
    option_index INTEGER NOT NULL,
    PRIMARY KEY (message_id, user_id, option_index)
);

CREATE TABLE IF NOT EXISTS wipe_events (
    message_id   INTEGER PRIMARY KEY,
    guild_id     INTEGER NOT NULL,
    channel_id   INTEGER NOT NULL,
    creator_id   INTEGER NOT NULL,
    creator_name TEXT    NOT NULL,
    title        TEXT    NOT NULL,
    description  TEXT    NOT NULL DEFAULT '',
    server       TEXT,
    ts           INTEGER NOT NULL,
    ask_reason   INTEGER NOT NULL DEFAULT 0,
    ping_role_id INTEGER,
    closed       INTEGER NOT NULL DEFAULT 0,
    reminded     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS wipe_responses (
    message_id INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    status     TEXT    NOT NULL,
    reason     TEXT,
    PRIMARY KEY (message_id, user_id)
);
"""

# Колонки, которые должны быть в tickets. База могла быть создана старой версией бота,
# поэтому при старте недостающие колонки добавляются через ALTER TABLE.
TICKET_COLUMNS = (
    ("priority", "TEXT NOT NULL DEFAULT 'normal'"),
    ("close_reason", "TEXT"),
    ("closed_by", "INTEGER"),
    ("rating", "INTEGER"),
    ("rating_comment", "TEXT"),
    ("last_activity", "INTEGER"),
    ("first_reply_at", "INTEGER"),
    ("locked", "INTEGER NOT NULL DEFAULT 0"),
    ("transcript", "TEXT"),
)


class Database:
    def __init__(self, path):
        self.path = Path(path)
        self._lock = threading.Lock()
        self._conn = None

    def connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)
        self._migrate()
        self._conn.commit()

    def _migrate(self):
        """Безопасно добавляет новые колонки в уже существующую базу."""
        existing = {row["name"] for row in self._conn.execute("PRAGMA table_info(tickets)")}
        for name, definition in TICKET_COLUMNS:
            if name not in existing:
                self._conn.execute(f"ALTER TABLE tickets ADD COLUMN {name} {definition}")
        # У старых тикетов нет времени последней активности — берём время создания.
        self._conn.execute(
            "UPDATE tickets SET last_activity=created_at WHERE last_activity IS NULL"
        )

    # --- низкий уровень (выполняется в потоке, чтобы не блокировать бота) ----
    def _execute(self, sql, params):
        with self._lock:
            cur = self._conn.execute(sql, params)
            self._conn.commit()
            return cur.rowcount, cur.lastrowid

    def _fetch(self, sql, params, one):
        with self._lock:
            cur = self._conn.execute(sql, params)
            return cur.fetchone() if one else cur.fetchall()

    async def execute(self, sql, params=()):
        """Выполняет запрос, возвращает число затронутых строк."""
        rowcount, _ = await asyncio.to_thread(self._execute, sql, tuple(params))
        return rowcount

    async def insert(self, sql, params=()):
        """Выполняет INSERT, возвращает id новой строки."""
        _, last_id = await asyncio.to_thread(self._execute, sql, tuple(params))
        return last_id

    async def fetchone(self, sql, params=()):
        return await asyncio.to_thread(self._fetch, sql, tuple(params), True)

    async def fetchall(self, sql, params=()):
        return await asyncio.to_thread(self._fetch, sql, tuple(params), False)

    # --- настройки сервера ---------------------------------------------------
    async def get_setting(self, guild_id, key, default=None):
        row = await self.fetchone(
            "SELECT value FROM settings WHERE guild_id=? AND key=?", (guild_id, key)
        )
        return row["value"] if row else default

    async def set_setting(self, guild_id, key, value):
        await self.execute(
            "INSERT INTO settings(guild_id, key, value) VALUES(?,?,?) "
            "ON CONFLICT(guild_id, key) DO UPDATE SET value=excluded.value",
            (guild_id, key, str(value)),
        )

    async def del_setting(self, guild_id, key):
        await self.execute("DELETE FROM settings WHERE guild_id=? AND key=?", (guild_id, key))

    # --- роли и каналы по назначению ----------------------------------------
    async def get_targets(self, guild_id, kind):
        rows = await self.fetchall(
            "SELECT target_id FROM guild_targets WHERE guild_id=? AND kind=?", (guild_id, kind)
        )
        return [r["target_id"] for r in rows]

    async def add_target(self, guild_id, kind, target_id):
        """True, если запись добавлена (раньше её не было)."""
        changed = await self.execute(
            "INSERT OR IGNORE INTO guild_targets(guild_id, kind, target_id) VALUES(?,?,?)",
            (guild_id, kind, target_id),
        )
        return changed > 0

    async def remove_target(self, guild_id, kind, target_id):
        """True, если запись была и удалена."""
        changed = await self.execute(
            "DELETE FROM guild_targets WHERE guild_id=? AND kind=? AND target_id=?",
            (guild_id, kind, target_id),
        )
        return changed > 0

    async def clear_targets(self, guild_id, kind):
        await self.execute("DELETE FROM guild_targets WHERE guild_id=? AND kind=?", (guild_id, kind))

    # --- типы обращений ------------------------------------------------------
    async def get_ticket_types(self, guild_id):
        """Типы обращений сервера. Если сервер своих не задал — значения из config."""
        rows = await self.fetchall(
            "SELECT key, label, emoji, description, slug FROM ticket_types "
            "WHERE guild_id=? ORDER BY position, rowid",
            (guild_id,),
        )
        if not rows:
            return [dict(t) for t in config.TICKET_TYPES]
        return [dict(row) for row in rows]

    async def _seed_ticket_types(self, guild_id):
        """Переносит типы по умолчанию в базу, чтобы их можно было менять и удалять."""
        row = await self.fetchone(
            "SELECT COUNT(*) AS n FROM ticket_types WHERE guild_id=?", (guild_id,)
        )
        if row and row["n"]:
            return
        for position, t in enumerate(config.TICKET_TYPES):
            await self.execute(
                "INSERT OR IGNORE INTO ticket_types(guild_id, key, label, emoji, description, slug, "
                "position) VALUES(?,?,?,?,?,?,?)",
                (guild_id, t["key"], t["label"], t["emoji"], t["description"], t["slug"], position),
            )

    async def add_ticket_type(self, guild_id, key, label, emoji, description, slug, position=100):
        await self._seed_ticket_types(guild_id)
        await self.execute(
            "INSERT INTO ticket_types(guild_id, key, label, emoji, description, slug, position) "
            "VALUES(?,?,?,?,?,?,?) ON CONFLICT(guild_id, key) DO UPDATE SET "
            "label=excluded.label, emoji=excluded.emoji, description=excluded.description, "
            "slug=excluded.slug",
            (guild_id, key, label, emoji, description, slug, position),
        )

    async def remove_ticket_type(self, guild_id, key):
        """True, если тип был и удалён."""
        await self._seed_ticket_types(guild_id)
        changed = await self.execute(
            "DELETE FROM ticket_types WHERE guild_id=? AND key=?", (guild_id, key)
        )
        return changed > 0

    # --- чёрный список тикетов ----------------------------------------------
    async def is_blacklisted(self, guild_id, user_id):
        """Возвращает строку чёрного списка или None."""
        return await self.fetchone(
            "SELECT * FROM ticket_blacklist WHERE guild_id=? AND user_id=?", (guild_id, user_id)
        )

    async def add_blacklist(self, guild_id, user_id, reason, added_by):
        await self.execute(
            "INSERT INTO ticket_blacklist(guild_id, user_id, reason, added_by, added_at) "
            "VALUES(?,?,?,?,?) ON CONFLICT(guild_id, user_id) DO UPDATE SET "
            "reason=excluded.reason, added_by=excluded.added_by, added_at=excluded.added_at",
            (guild_id, user_id, reason, added_by, int(now_ts())),
        )

    async def remove_blacklist(self, guild_id, user_id):
        """True, если пользователь был в списке."""
        changed = await self.execute(
            "DELETE FROM ticket_blacklist WHERE guild_id=? AND user_id=?", (guild_id, user_id)
        )
        return changed > 0

    async def list_blacklist(self, guild_id):
        return await self.fetchall(
            "SELECT * FROM ticket_blacklist WHERE guild_id=? ORDER BY added_at DESC", (guild_id,)
        )

    # --- шаблоны эмбедов -----------------------------------------------------
    async def save_template(self, guild_id, name, payload, author_id):
        await self.execute(
            "INSERT INTO embed_templates(guild_id, name, payload, author_id, created_at) "
            "VALUES(?,?,?,?,?) ON CONFLICT(guild_id, name) DO UPDATE SET "
            "payload=excluded.payload, author_id=excluded.author_id, created_at=excluded.created_at",
            (guild_id, name, json.dumps(payload, ensure_ascii=False), author_id, int(now_ts())),
        )

    async def load_template(self, guild_id, name):
        """Возвращает словарь шаблона или None."""
        row = await self.fetchone(
            "SELECT payload FROM embed_templates WHERE guild_id=? AND name=?", (guild_id, name)
        )
        if row is None:
            return None
        try:
            return json.loads(row["payload"])
        except (ValueError, TypeError):
            return None

    async def list_templates(self, guild_id):
        return await self.fetchall(
            "SELECT name, author_id, created_at FROM embed_templates WHERE guild_id=? ORDER BY name",
            (guild_id,),
        )

    async def delete_template(self, guild_id, name):
        """True, если шаблон был и удалён."""
        changed = await self.execute(
            "DELETE FROM embed_templates WHERE guild_id=? AND name=?", (guild_id, name)
        )
        return changed > 0

    # --- карточки участников клана -------------------------------------------
    async def get_clan_member(self, guild_id, user_id):
        return await self.fetchone(
            "SELECT * FROM clan_members WHERE guild_id=? AND user_id=?", (guild_id, user_id)
        )

    async def set_clan_member(self, guild_id, user_id, nick=None, hours=None, timezone=None, note=None):
        """Обновляет только переданные поля, остальные оставляет как были."""
        old = await self.get_clan_member(guild_id, user_id)
        values = {
            "nick": nick if nick is not None else (old["nick"] if old else None),
            "hours": hours if hours is not None else (old["hours"] if old else None),
            "timezone": timezone if timezone is not None else (old["timezone"] if old else None),
            "note": note if note is not None else (old["note"] if old else None),
        }
        await self.execute(
            "INSERT INTO clan_members(guild_id, user_id, nick, hours, timezone, note, updated_at) "
            "VALUES(?,?,?,?,?,?,?) ON CONFLICT(guild_id, user_id) DO UPDATE SET "
            "nick=excluded.nick, hours=excluded.hours, timezone=excluded.timezone, "
            "note=excluded.note, updated_at=excluded.updated_at",
            (guild_id, user_id, values["nick"], values["hours"], values["timezone"],
             values["note"], int(now_ts())),
        )

    async def clear_clan_member(self, guild_id, user_id):
        """True, если карточка была и удалена."""
        changed = await self.execute(
            "DELETE FROM clan_members WHERE guild_id=? AND user_id=?", (guild_id, user_id)
        )
        return changed > 0

    async def list_clan_members(self, guild_id):
        return await self.fetchall(
            "SELECT * FROM clan_members WHERE guild_id=? ORDER BY COALESCE(hours, 0) DESC, nick",
            (guild_id,),
        )
