"""Единый стиль эмбедов VEX."""
import discord

from . import config


def make(title=None, description=None, color=config.COLOR_MAIN, footer=True):
    embed = discord.Embed(title=title, description=description, color=color)
    if footer:
        embed.set_footer(text=config.FOOTER)
    return embed


def ok(text, title="Готово"):
    return make(f"✅ {title}", text, config.COLOR_OK)


def err(text, title="Ошибка"):
    return make(f"⛔ {title}", text, config.COLOR_ERR)


def warn(text, title="Внимание"):
    return make(f"⚠️ {title}", text, config.COLOR_WARN)


def info(text, title=None):
    return make(title, text)
