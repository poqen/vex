"""Настройки и константы VEX. Всё, что хочется поменять «под себя», — здесь."""
import os
from pathlib import Path

try:  # .env нужен только для локального запуска; на хостинге переменные задаются в панели
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass


def _int(name: str, default: int = 0) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


# --- Окружение -------------------------------------------------------------
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
GUILD_ID = _int("GUILD_ID")  # ID сервера: команды появятся сразу. Пусто = глобальная синхронизация (до часа)
DATA_DIR = Path(os.getenv("DATA_DIR", "./data"))  # здесь лежит база. На хостинге — путь к постоянному диску!
TRANSCRIPT_DIR = DATA_DIR / "transcripts"  # сюда складываются HTML и TXT транскрипты закрытых тикетов
TIMEZONE = os.getenv("TIMEZONE", "Europe/Moscow")

# --- Оформление ------------------------------------------------------------
BRAND = "VEX"
FOOTER = "VEX • Clan Control"
COLOR_MAIN = 0x8B5CF6  # фиолетовый
COLOR_DARK = 0x6D28D9  # тёмно-фиолетовый (закрытые события)
COLOR_OK = 0x22C55E
COLOR_ERR = 0xEF4444
COLOR_WARN = 0xF59E0B

# Названия цветов для конструктора эмбедов (/say). Можно дописывать свои.
NAMED_COLORS = {
    "purple": COLOR_MAIN,
    "фиолетовый": COLOR_MAIN,
    "dark": COLOR_DARK,
    "green": COLOR_OK,
    "зелёный": COLOR_OK,
    "зеленый": COLOR_OK,
    "red": COLOR_ERR,
    "красный": COLOR_ERR,
    "orange": COLOR_WARN,
    "оранжевый": COLOR_WARN,
    "blue": 0x3B82F6,
    "синий": 0x3B82F6,
    "blurple": 0x5865F2,
    "black": 0x0F0A1F,
    "white": 0xFFFFFF,
    "gold": 0xF1C40F,
}

# --- Тикеты: типы обращений (меню на панели). Меняй как угодно, до 25 штук. ---
# Это значения «по умолчанию»: сервер может задать свои через /ticket type add.
TICKET_TYPES = [
    {"key": "join", "slug": "join", "label": "Вступление в клан", "emoji": "🛡️",
     "description": "Подать заявку на вступление"},
    {"key": "question", "slug": "question", "label": "Вопрос", "emoji": "❓",
     "description": "Задать вопрос администрации"},
    {"key": "report", "slug": "report", "label": "Жалоба", "emoji": "🚨",
     "description": "Жалоба на игрока или участника клана"},
    {"key": "appeal", "slug": "appeal", "label": "Обжалование наказания", "emoji": "⚖️",
     "description": "Оспорить мут, бан или предупреждение"},
    {"key": "other", "slug": "other", "label": "Другое", "emoji": "📨",
     "description": "Всё остальное"},
]

# --- Тикеты: приоритеты -----------------------------------------------------
PRIORITY_ORDER = ("low", "normal", "high", "urgent")
PRIORITY_LABELS = {
    "low": "🟢 Низкий",
    "normal": "🔵 Обычный",
    "high": "🟠 Высокий",
    "urgent": "🔴 Срочный",
}
# Префикс имени канала: срочные тикеты видно в списке каналов сразу.
PRIORITY_CHANNEL_PREFIX = {
    "low": "",
    "normal": "",
    "high": "🟠-",
    "urgent": "🔴-",
}

# --- Автомодерация: домены, которые разрешены всегда ------------------------
DEFAULT_ALLOWED_DOMAINS = (
    "tenor.com",
    "giphy.com",
    "cdn.discordapp.com",
    "media.discordapp.net",
)

# --- Ключи команд для системы доступа (/perms) -------------------------------
COMMAND_KEYS = {
    "ticket_admin": "Панель и настройка тикетов",
    "ticket_manage": "Работа с тикетами (закрыть, добавить, взять)",
    "role": "Выдача и снятие ролей (/role add, /role remove)",
    "role_admin": "Список ролей, которые можно выдавать (/role allow)",
    "wipe": "Вайп-реакты, /noreact и /wipe stats",
    "automod": "Настройка автомодерации",
    "autorole": "Настройка авто-выдачи ролей",
    "say": "Сообщения и конструктор эмбедов (/say)",
    "roster": "Состав клана и чужие карточки (/roster, /nick clear)",
    "poll": "Голосования (/poll)",
}
