"""Система доступа: какая роль может пользоваться какой командой.

Правило простое:
  * администраторы и владелец сервера могут всё;
  * остальным нужна роль, которой выдан доступ командой /perms grant;
  * пока доступ никому не выдан, команда доступна только администраторам.
"""
import discord
from discord import app_commands


class NoAccess(app_commands.CheckFailure):
    def __init__(self, key=None, admin_only=False):
        self.key = key
        self.admin_only = admin_only
        super().__init__("Нет доступа к команде")


def is_admin(member):
    return member.guild_permissions.administrator or member.guild.owner_id == member.id


async def member_has_access(bot, member, key):
    if not isinstance(member, discord.Member):
        return False
    if is_admin(member):
        return True
    allowed = await bot.db.get_targets(member.guild.id, f"cmd:{key}")
    return any(role.id in allowed for role in member.roles)


def access(key):
    """Декоратор слеш-команды: доступ по ролям из /perms."""

    async def predicate(interaction):
        if await member_has_access(interaction.client, interaction.user, key):
            return True
        raise NoAccess(key)

    return app_commands.check(predicate)


def admin_only():
    """Декоратор слеш-команды: только администраторы (для /perms и /config)."""

    async def predicate(interaction):
        user = interaction.user
        if isinstance(user, discord.Member) and is_admin(user):
            return True
        raise NoAccess(admin_only=True)

    return app_commands.check(predicate)
